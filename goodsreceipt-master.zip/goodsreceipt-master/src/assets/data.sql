CREATE TABLE IF NOT EXISTS USER_DETAILS(USERID INTEGER PRIMARY KEY,
                                        PERSONID INTEGER,
                                        USERNAME TEXT,
                                        FULLNAME TEXT,
                                        PASSWORD TEXT,
                                        STATUS INTEGER);

CREATE TABLE IF NOT EXISTS PURCHASEORDER_LIST(PO_NUMBER INTEGER NOT NULL,
                                              RELEASES INTEGER,
                                              PO_HEADER_ID INTEGER,
                                              PO_TYPE TEXT,
                                              VENDOR_NAME TEXT,
                                              VENDOR_SITE TEXT,
                                              ITEMS TEXT,
                                              CONTRACT TEXT,
                                              REQUESTOR TEXT,
                                              PO_HDR_PRICE INTEGER,
                                              PO_RELEASE_ID INTEGER,
                                              CURRENCY_CODE TEXT,
                                              CREATION_DATE TEXT,
                                              LAST_UPDATE_DATE TEXT,
                                              PRIMARY KEY(PO_NUMBER,RELEASES));

CREATE TABLE IF NOT EXISTS PURCHASEORDER_ITEMS(LINE_LOCATION_ID INTEGER PRIMARY KEY,
                                               ITEM TEXT,
                                               SHIPMENT_NUM INTEGER,
                                               LINE_NUM INTEGER,
                                               DESCRIPTION TEXT,
                                               QUAN_ORD TEXT,
                                               QUAN_RECV TEXT,
                                               UOM TEXT,
                                               RELEASENUM INTEGER,
                                               ORGID INTEGER,
                                               POHEADERID INTEGER,
                                               DELIVERY_DATE TEXT);

CREATE TABLE IF NOT EXISTS PO_ITEM_DETAILS(LINE_LOCATION_ID INTEGER PRIMARY KEY,
                                           ITEM TEXT,
                                           INVENTORY_ITEM_ID INTEGER,
                                           DELIVERY_TO TEXT,
                                           DESCRIPTION TEXT,
                                           CATEGORY TEXT,
                                           ORDER_QTY TEXT,
                                           SHIPMENT INTEGER,
                                           DESTINATION_TYPE TEXT,
                                           OVERRIDE TEXT,
                                           SUBINVENTORY TEXT,
                                           QUNATITY_RECV TEXT,
                                           RECEIPT_DATE TEXT,
                                           PO_HEADER_ID INTEGER,
                                           PO_RELEASE_ID INTEGER,
                                           PO_LINE_ID INTEGER,
                                           PO_DISTRIBUTION_ID INTEGER,
                                           PO_LINE_NUMBER INTEGER,
                                           RELESENUM INTEGER,
                                           SHIP_TO_LOCATION_ID INTEGER,
                                           CURRENCY_CODE TEXT,
                                           ORG_ID INTEGER);

CREATE TABLE IF NOT EXISTS SUBINVENTORY(ORGANIZATION_ID INTEGER PRIMARY KEY,SUBINVENTORY TEXT);

CREATE TABLE IF NOT EXISTS LOCATORS(ID INTEGER PRIMARY KEY AUTOINCREMENT, LOCATOR_LIST TEXT,LOCATOR_TYPE TEXT);

CREATE TABLE IF NOT EXISTS LOTNUMBERS(ID INTEGER PRIMARY KEY AUTOINCREMENT,
                                      LOT_NUMBER TEXT,
                                      LOT_TYPE TEXT,
                                      LOT_GENERATION TEXT);

CREATE TABLE IF NOT EXISTS SERIALNUMBERS(SERIAL_NUMBER TEXT,
                                         SERIAL_TYPE TEXT);

CREATE TABLE IF NOT EXISTS OPERATINGUNIT(ORG_ID INTEGER PRIMARY KEY,
                                         OPERATING_UNIT_NAME TEXT);

CREATE TABLE IF NOT EXISTS INVENTORY_ORG(INV_ORG_ID INTEGER PRIMARY KEY,
                                         INVENTORY_ORGANIZATION_NAME TEXT);

CREATE TABLE IF NOT EXISTS RECEIPT_ITEM_DETAILS(LINE_LOCATION_ID INTEGER PRIMARY KEY,
                                                DESTINATION TEXT,
                                                OVERRIDE_STATUS TEXT,
                                                SUBINVENTORY TEXT,
                                                QUNATITY_RECV TEXT,
                                                RECEIPT_DATE TEXT,
                                                LOCATOR TEXT,
                                                LOT TEXT,
                                                MIN_SERIAL TEXT,
                                                MAX_SERIAL TEXT,
                                                USERID INTEGER);

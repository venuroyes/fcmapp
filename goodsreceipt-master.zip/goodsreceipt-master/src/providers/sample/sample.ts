import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { AlertController, LoadingController } from "ionic-angular";
/*
  Generated class for the SampleProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
@Injectable()
export class SampleProvider {

/**
   * Value for loading controller.
   */
  loading = this.loadingCtrl.create({
    content: 'Please wait...'
  });

  constructor(public http: Http, public alertCtrl: AlertController, public loadingCtrl: LoadingController) {
    console.log('Hello SampleProvider Provider');
  }

  /**
   * Method to get the data from local json file with faq's.
   */
  getFaqData() {
    var response = this.http.get('assets/faq.json').map(res => res.json());
    return response;
  }


  /**
   * Method to call the rest service with headers and request body using http post method.
   *
   * @param url Rest service.
   * @param property Request body.
   */
  getInventory(url, property) {
    let body = JSON.stringify(property);
    let headers = new Headers({'Content-Type':'application/json', 'Accept':'application/json', 'Content-Language':'en-US', 'Authorization':'Basic c3lzYWRtaW46b3JhY2xlMTIz'});
    let options = new RequestOptions({ headers: headers });
    return this.http.post(url, body, options)
      .map(res => res.json())
      .catch(this.handleError);
  }

  /**
   * Method to get the data from local json file for demo mode of the app.
   */
  getJsonData(){
    var result=this.http.get("assets/demo.json").map(res=>res.json());
    return result;
  }

  /**
   * Method to get the value for demo subinventory data from local json file.
   */
  getSubInventoryJsonData() {
    var response = this.http.get('assets/subinventory.json').map(res => res.json());
    return response;
  }

  /**
   * Method to handle the error while calling the service.
   *
   * @param error Error message while calling the rest service.
   */
  handleError(error) {
    console.error(error);
    return Observable.throw(error.json().error || 'Server error');
  }

  /**
   * Method to display the alert when username is incorrect.
   */
  userAlert() {
    let alert = this.alertCtrl.create({
      title: 'Please enter username',
      buttons: [
        { text: "ok" }
      ]

    });
    return alert.present();

  }

  /**
   * Method to display alert when password is incorrect.
   */
  passwordAlert() {
    let alert = this.alertCtrl.create({
      title: 'Please enter password',
      buttons: [
        { text: "ok" }
      ]

    });
    return alert.present();

  }

  /**
   * Method to display alert when user entered wrong credentials.
   */
  presentUserAlert() {
    let alert = this.alertCtrl.create({
      title: 'Please enter correct credentials',
      buttons: [
        { text: "ok" }
      ]

    });
    return alert.present();

  }

  /**
   * Method to show loading icon.
   */
  showLoading() {

    return this.loading.present();

  }

  /**
   * Method to close the loading icon.
   */
  offLoading() {
    return this.loading.dismiss();
  }

}

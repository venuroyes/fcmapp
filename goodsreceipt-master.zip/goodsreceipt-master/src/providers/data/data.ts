import { Injectable } from '@angular/core';
import { Http ,Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { AlertController,LoadingController } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';

/*
  Generated class for the DataProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
/**
 * Provider to get the data from rest services using http calls.
 */
@Injectable()
export class DataProvider {

  /**
   * Value for loading controller.
   */
   loading = this.loadingCtrl.create({
    content: 'Please wait...'
  });

  constructor(public http: Http, public alertCtrl:AlertController, public loadingCtrl: LoadingController) {
    console.log('Hello DataProvider Provider');
  }

  /**
   * Method to get data from local json file for demo mode of the app.
   */
   getJsonData() {
    var response = this.http.get('assets/demo.json').map(res => res.json());
    return response;
  }

  /**
   * Method to get subinventory data from local json file for demo mode.
   */
  getSubInventoryJsonData() {
    var response = this.http.get('assets/subinventory.json').map(res => res.json());
    return response;
  }

  /**
   * Method to get data for faq's from local file.
   */
  getFaqData() {
    var response = this.http.get('assets/faq.json').map(res => res.json());
    return response;
  }

  /**
   * Method for getting the data from rest service using http post method.
   * 
   * @param url Rest service.
   * @param property Request body.
   */
  getCommonData(url, property) {
    let body = JSON.stringify(property);
    /**
     * Headers for the rest service.
     */
    let headers = new Headers({'Content-Type':'application/json', 'Accept':'application/json', 'Content-Language':'en-US', 'Authorization':'Basic c3lzYWRtaW46b3JhY2xlMTIz'});
    // let headers = new Headers({ 'Content-Type': 'application/json', 'Authorization': 'Basic SU5BTEdBUllUTVRSSUFMMTNTRVAxN19ERVZFTE9QTUVOVDAxX01PQklMRV9BTk9OWU1PVVNfQVBQSUQ6RmNkNV9mcGd0eWs5anM=', 'oracle-mobile-backend-id': 'fb2d242d-15cc-4710-9aef-99b1f584389f' });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(url, body, options)
      .map(res => res.json())
      .catch(this.handleError);
  }

    /**
   * Method for getting the data from rest service using http post method.
   * 
   * @param url Rest service.
   * @param property Request body.
   */
   getInventoryData(url, property) {
    let body = JSON.stringify(property);
    let headers = new Headers({'Content-Type':'application/json', 'Accept':'application/json', 'Content-Language':'en-US', 'Authorization':'Basic c3lzYWRtaW46b3JhY2xlMTIz'});
    // let headers = new Headers({ 'Content-Type': 'application/json', 'Authorization': 'Basic SU5BTEdBUllUTVRSSUFMMTNTRVAxN19ERVZFTE9QTUVOVDAxX01PQklMRV9BTk9OWU1PVVNfQVBQSUQ6RmNkNV9mcGd0eWs5anM=', 'oracle-mobile-backend-id': 'bced4290-a5b1-4650-a3d8-0d5748ba8598' });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(url, body, options)
      .map(res => res.json())
      .catch(this.handleError);
  }

    /**
   * Method for getting the data from rest service using http post method.
   * 
   * @param url Rest service.
   * @param property Request body.
   */
  getGoodsData(url, property) {
    let body = JSON.stringify(property);
    let headers = new Headers({'Content-Type':'application/json', 'Accept':'application/json', 'Content-Language':'en-US', 'Authorization':'Basic c3lzYWRtaW46b3JhY2xlMTIz'});
    // let headers = new Headers({ 'Content-Type': 'application/json', 'Authorization': 'Basic SU5BTEdBUllUTVRSSUFMMTNTRVAxN19ERVZFTE9QTUVOVDAxX01PQklMRV9BTk9OWU1PVVNfQVBQSUQ6RmNkNV9mcGd0eWs5anM=', 'oracle-mobile-backend-id': 'fcaef239-7e06-4fda-bf48-26bf0bb0ca96' });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(url, body, options)
      .map(res => res.json())
      .catch(this.handleError);
  }

    /**
   * Method for getting the data from rest service using http post method.
   * 
   * @param url Rest service.
   * @param property Request body.
   */
  getData(url, property) {
    let body = JSON.stringify(property);
    let headers = new Headers({'Content-Type':'application/json', 'Accept':'application/json', 'Content-Language':'en-US', 'Authorization':'Basic c3lzYWRtaW46b3JhY2xlMTIz'});
    // let headers = new Headers({ 'Content-Type': 'application/json', 'Authorization': 'Basic SU5BTEdBUllUTVRSSUFMMTNTRVAxN19ERVZFTE9QTUVOVDAxX01PQklMRV9BTk9OWU1PVVNfQVBQSUQ6RmNkNV9mcGd0eWs5anM=', 'oracle-mobile-backend-id': '1f07d90d-aecd-4109-a56c-52faae1a5097' });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(url, body, options)
      .map(res => res.json())
      .catch(this.handleError);
  }

  /**
   * Method to handle the errors while calling the service.
   * 
   * @param error Error when service call fails.
   */
  handleError(error) {
    console.error(error);
    return Observable.throw(error.json().error || 'Server error');
  }

  /**
   * Method to show alert when user entered wrong name.
   */
   userAlert() {
    let alert = this.alertCtrl.create({
      title: 'Please enter username',
      buttons: [
        { text: "ok" }
      ]

    });
    return alert.present();

  }

  /**
   * Method to show alert when user entered wrong password.
   */
  passwordAlert() {
    let alert = this.alertCtrl.create({
      title: 'Please enter password',
      buttons: [
        {
          text: "ok"
        }
      ]

    });
    return alert.present();

  }

  /**
   * Method to show loading icon.
   */
   showLoading() {
    return this.loading.present();
  }

  /**
   * Method to stop loading icon.
   */
  offLoading() {
    return this.loading.dismiss();
  }

}

import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { Network } from '@ionic-native/network';
import { Platform } from 'ionic-angular';

/*
  Generated class for the NetworkProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
/**
 * Provider to check the network connection.
 */
declare var Connection;
@Injectable()
export class NetworkProvider {
/**
 * Value for ondevice.
 */
  onDevice: boolean;
  constructor(public http: Http,public platform: Platform,private network:Network) {
    this.onDevice = this.platform.is('cordova');
    console.log('Hello NetworkProvider Provider');
  }

  /**
   * Method to check if online or not.
   */
   isOnline(): boolean {
    if(this.onDevice && this.network.type){
      return this.network.type !== Connection.NONE;
    } else {
      return navigator.onLine;
    }
  }

  /**
   * Method to check isoffline or not.
   */
  isOffline(): boolean {
    if(this.onDevice && this.network.type){
      return this.network.type === Connection.NONE;
    } else {
      return !navigator.onLine;
    }
  }

}

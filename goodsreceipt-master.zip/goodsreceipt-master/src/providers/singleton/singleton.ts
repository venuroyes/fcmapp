import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

/*
  Generated class for the SingletonProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
/**
 * Provider to have the all the rest services required for the app.
 */
@Injectable()
export class SingletonProvider {

  /**
   * Base url for the mcs rest services.
   */
  baseUrl: string = "https://development01-inalgarytmtrial13sep17.mobileenv.us2.oraclecloud.com:443/mobile/custom/";
  /**
   * Base url for nonmcs services.
   */
  demoBaseUrl: string = "http://cloud.algarytm.com:8000/webservices/rest/";
  constructor(public http: Http) {
    console.log('Hello SingletonProvider Provider');
  }
  // here we are having all the apis
  // public loginUrl: string = this.baseUrl + "PO_LOGIN/PO_LOGIN";
  // public inventoryOrgList: string = this.baseUrl + "INV_ORGANISATION/INV_ORGN";
  // public operatingUnitList: string = this.baseUrl + "INV_Operating_Unitlist/Operating_Unitlist";
  // public poList: string = this.baseUrl + "GOODS_RECEIPTS_PO_LIST/GOODS_RCPTS_PO_LST";
  // public poLineDetails: string = this.baseUrl + "GDS_PO_LINE_DTLS/po_ln_details";
  // public poItemDetails: string = this.baseUrl + "GOODS_PO_ITEM_DTLS/gds_po_item_dtls";
  // public locators: string = this.baseUrl + "PO_LOCATOR/PO_locators";
  // public storageLocations: string = this.baseUrl + "STRG_LOCATIONS/STRG_LOCATIONS";
  // public lotNumbers: string = this.baseUrl + "PO_LOT_NUMBERS/PO_LOT_NUMBER";
  // public serialNumbers: string = this.baseUrl + "PO_SERIAL_NUMBERS/SERIAL_NUMBERS";
  // public logoutUrl: string = this.baseUrl + "logout_API/status";
  // public barcodeHdr : string = this.baseUrl + "Gds_barcode_hdr/gds_barcode_hdr";

  // url using isg services

  /**
   * Login rest service.
   */
  public loginUrl: string = this.demoBaseUrl+"INV_PO_LOGIN/get_login_status_f/";
  /**
   * Operating unit rest service.
   */
  public operatingUnitList: string = this.demoBaseUrl + "INV_OULIST/get_org_id_f/";
  /**
   * Inventory org list rest service.
   */
  public inventoryOrgList: string = this.demoBaseUrl + "INV_ORGN/get_organization_f/";
  /**
   * Polist rest service.
   */
  public poList: string = this.demoBaseUrl + "GDS_RCPTS_PO_LIST/get_po_list_f/";
  /**
   * polist with date rest service.
   */
  public poListDate: string = this.demoBaseUrl + "GDS_PO_LIST_DLD/get_po_list_f/";
  /**
   * Polines rest service.
   */
  public poLineDetails: string = this.demoBaseUrl + "GDS_PO_LN_DTLS/get_po_line_dtls_f/";
  /**
   * Poitem details rest service.
   */
  public poItemDetails: string = this.demoBaseUrl + "GOODS_PO_ITM_DTLS/get_po_item_dtls_f/";
  /**
   * Locators list rest service. 
   */
  public locators: string = this.demoBaseUrl + "INV_LOCATORS/get_locator_f/";
  /**
   * Storage location or subinventory rest service.
   */
  public storageLocations: string = this.demoBaseUrl + "INV_STRG_LOCATIONS/get_storage_location_f/";
  /**
   * Lotnumbers rest service.
   */
  public lotNumbers: string = this.demoBaseUrl + "INV_LOT_NUMBERS/get_lot_number_f/";
  /**
   * Serial numbers rest service.
   */
  public serialNumbers: string = this.demoBaseUrl + "INV_SERIAL_NUMBERS/get_serial_f/";
  /**
   * Logout rest service.
   */
  public logoutUrl: string = this.demoBaseUrl + "SECURITY_UTIL/logout_user_f/";
  /**
   * Barcode rest service.
   */
  public barcodeHdr : string = this.demoBaseUrl + "GDS_BARCDE_HDR/get_barcode_header_f/";
  /**
   * Interface rest service.
   */
  public interfacecsv : string = this.demoBaseUrl + "parse_csv/get_parse_csv_p/";
}

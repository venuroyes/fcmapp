import { Injectable } from '@angular/core';
// import { Http } from '@angular/http';
// import 'rxjs/add/operator/map';

/*
  Generated class for the GlobalvariablesProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
/**
 * Provider to have the globalvariables that are used accross the application.
 */
@Injectable()
export class GlobalvariablesProvider {
  /**
   * Value for demo.
   */
  demo;
  /**
   * Value for username.
   */
  username;
  /**
   * Value for userfullname.
   */
  userFullName;
  /**
   * Value for userid.
   */
  userId;
  /**
   * Value for orgid.
   */
  orgid;
  /**
   * Value for inventory org id.
   */
  inv_org_id;
  /**
   * Value for poheaderid.
   */
  poHeaderId;
  /**
   * Value for delivery date.
   */
  deliveryDate;
  /**
   * Value for showform.
   */
  showform;
  /**
   * value for user.
   */
  user;
  /**
   * Value for password.
   */
  password;

 /**
   * Value for destination.
   */
  destination;

  /**
   * Value for subInventory.
   */
  subInventory;

  /**
   * Value for Locators.
   */

  Locators;
   /**
   * Value for lot number.
   */

  lotnumber;
   /**
   * Value for minserialnumber.
   */

  Minserialnumber;

  /**
   * Value for Maxserialnumber.
   */
  Maxserialnumber;

 /**
  *  Value for item
  */
  item;

/**
  *  Value for ponumber
  */
 ponumber;

 llid:any;
  constructor() {
    console.log('Hello GlobalvariablesProvider Provider');
    this.demo="";
    this.username="";
    this.userFullName="";
    this.userId="";
    this.orgid="";
    this.inv_org_id="";
    this.poHeaderId="";
    this.deliveryDate="";
    this.showform="";
    this.user="";
    this.password="";
    this.subInventory='';
    this.Locators='';
    this.lotnumber='';
    this.Minserialnumber='';
    this.Maxserialnumber='';
  }

  /**
  *  subinventory
  */

  setsubInventory(value){
  this.subInventory=value;
  }

   /**
  *  subinventory
  */
  getsubInventory(){
  return this.subInventory;
  }
  /**
  *  Locators
  */
  setLocators(value){
    this.Locators=value;
  }

  /**
  *   Locators
  */
  getLocators(){
    return this.Locators;
  }

  /**
  *   Lotnumbers
  */
  setlotnumber(value){
    this.lotnumber=value;
  }

  /**
  *   Lotnmubers
  */
  getlotnumber(){
  return this.lotnumber;
  }

  /**
  *    Minserialnumber
  */
  setMinserialnumber(value){
   this.Minserialnumber=value;
   }

   /**
  *   Minserialnumber
  */
  getMinserialnumber(){
  return this.Minserialnumber;
  }

  /**
  *   Maxserialnumber
  */

  setMaxserialnumber(value){
  this.Maxserialnumber=value;
  }

  /**
  *   Maxserialnumber
  */

  getMaxserialnumber(){
  return this.Maxserialnumber ;
  }

  /**
   *
   * @ignore
   */
  setUser(value){
    this.user=value;
  }

  /**
   *
   * @ignore
   */
  getUser(){
    return this.user;
  }

  /**
   *
   * @ignore
   */
  setPassword(value){
    this.password=value;
  }

  /**
   *
   * @ignore
   */
  getPassword(){
    return this.password;
  }

  /**
   *
   * @ignore
   */
  setShowForm(value){
    this.showform=value;
  }

  /**
   *
   * @ignore
   */
  getShowForm(){
    return this.showform;
  }

  /**
   *
   * @ignore
   */
  setDemo(value){
    this.demo=value;
  }

  /**
   *
   * @ignore
   */
  getDemo(){
    return this.demo;
  }

  /**
   *
   * @ignore
   */
  setUsername(value){
    this.username=value;
  }

  /**
   *
   * @ignore
   */
  getUsername(){
    return this.username;
  }

  /**
   *
   * @ignore
   */
  setUserFullName(value){
    this.userFullName=value;
  }

  /**
   *
   * @ignore
   */
  getUserFullName(){
    return this.userFullName;
  }

  /**
   *
   * @ignore
   */
  setUserId(value){
    this.userId=value;
  }

  /**
   *
   * @ignore
   */
  getUserId(){
    return this.userId;
  }

  /**
   *
   * @ignore
   */
  setOrgId(value){
    this.orgid=value;
  }

  /**
   *
   * @ignore
   */
  getOrgId(){
    return this.orgid;
  }

  /**
   *
   * @ignore
   */
  setInvOrgId(value){
    this.inv_org_id=value;
  }

  /**
   *
   * @ignore
   */
  getInvOrgId(){
    return this.inv_org_id;
  }

  /**
   *
   * @ignore
   */
  setPoHeaderId(value){
    this.poHeaderId=value;
  }

  /**
   *
   * @ignore
   */
  getPoHeaderId(){
    return this.poHeaderId;
  }

  /**
   *
   * @ignore
   */
  setDeliveryDate(value){
    this.deliveryDate = value;
  }

  /**
   *
   * @ignore
   */
  getDeliveryDate(){
    return this.deliveryDate;
  }

   /**
   *
   * @ignore
   */
  setdestination(value){
    this.destination = value;
  }

  /**
   *
   * @ignore
   */
  getdestination(){
    return this.destination;
  }

   /**
   *
   * @ignore
   */
 setItem(item){
 this.item=item;
 }
 /**
   *
   * @ignore
   */

 getItem(){
   return this.item;
 }
 /**
   *
   * @ignore
   */
  setponumber(item){
    this.ponumber=item;
    }
    /**
      *
      * @ignore
      */

    getponumber(){
      return this.ponumber;
    }

/**
   *
   * @ignore
   */
  setlinelocationid(item){
    this.llid=item;
    }
    /**
      *
      * @ignore
      */

    getlinelocationid(){
      return this.llid;
    }

}

import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { BehaviorSubject } from 'rxjs/Rx';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';
import { Storage } from '@ionic/storage';
import { SQLitePorter } from '@ionic-native/sqlite-porter';
import { Platform } from 'ionic-angular';
import { IonicStorageModule } from '@ionic/storage';

/*
  Generated class for the DatabaseProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
/**
 * Provider to do CRUD operations on Sqlite database.
 */
@Injectable()
export class DatabaseProvider {
  database: SQLiteObject;
  private databaseReady: BehaviorSubject<boolean>;
  constructor(public http: Http, private sqlite: SQLite, private sqliteporter: SQLitePorter, private storage: Storage, private platform: Platform) {
    console.log('Hello DatabaseProvider Provider');
    this.databaseReady = new BehaviorSubject(false);
    this.platform.ready().then(() => {
      /**
       * Create the Sqlite database.
       */
      this.sqlite.create({
        name: 'goodsreceipt.db',
        location: 'default'
      })
        .then((db: SQLiteObject) => {
          this.database = db;
          this.storage.get('database_filled').then(val => {
            if (val) {
              this.databaseReady.next(true);
            } else {
              this.fillDatabase();
            }
          })
        });
    });

    // this.sqlite.create({name: "goodsreceipt.db", location: "default"}).then((db : SQLiteObject) => {
    //                 this.database = db;
    //                 this.createTables();
    //             }, (error) => {
    //                 console.log("ERROR: ", error);
    //         });
  }

  //filling the database or creating the tables using the sql file

  /**
   * Method to create the tables in database using the local sql file.
   */
  fillDatabase() {
    this.http.get('assets/data.sql')
      .map(res => res.text())
      .subscribe(sql => {
        /**
         * Sqlite porter to import data form sql file.
         */
        this.sqliteporter.importSqlToDb(this.database, sql)
          .then(data => {
            this.databaseReady.next(true);
            this.storage.set('database_filled', true);
          })
          .catch(e => console.log(e));
      });
  }

  // inserting data into the tables of database
  /**
   * Method to insert the data into database after successful login.
   *
   * @param item Object from the login service.
   * @param pass User entered password.
   */
  insertIntoUserDetails(item, pass) {
    let sqlQuery = "INSERT INTO USER_DETAILS(USERID, PERSONID, USERNAME, FULLNAME, PASSWORD, STATUS) VALUES (?,?,?,?,?,?)";
    console.log(item);
    let values = [parseInt(item.USER_ID) || null, parseInt(item.PERSON_ID) || null, item.USER_NAME || null, item.FULL_NAME || null, pass, item.STATUS || null];
    return this.database.executeSql(sqlQuery, values);
  }

  // insert polist items

  /**
   * Method to insert the po list data into Sqlite database.
   *
   * @param item Item from the polist service.
   */
  insertIntoPoList(item) {
    // console.log(item + "this is item");
    // console.log(item.length + "this is the length");
    for (let i = 0; i < item.length; i++) {
      // v = item[i];
      var ponumber = parseInt(item[i].PO_NUMBER);
      var releases = parseInt(item[i].RELEASES);
      var poheaderid = parseInt(item[i].PO_HEADER_ID);
      var potype = item[i].PO_TYPE;
      var vendorname = item[i].VENDOR_NAME;
      var vendorsite = item[i].VENDOR_SITE;
      var items = parseInt(item[i].ITEMS);
      var contract = item[i].CONTRACT;
      var requestor = item[i].REQUESTOR;
      var pohdrprice = parseInt(item[i].PO_HDR_PRICE);
      var poreleaseid = parseInt(item[i].RELEASE_ID);
      var currencycode = item[i].CURRENCY_CODE;
      var creationdate = item[i].CREATION_DATE;
      var lastupdatedate = item[i].LAST_UPDATE_DATE;

      // values = [parseInt(v.PO_NUMBER), parseInt(v.RELEASES), parseInt(v.PO_HEADER_ID), v.PO_TYPE, v.VENDOR_NAME, v.VENDOR_SITE, parseInt(v.ITEMS), v.CONTRACT, v.REQUESTOR, parseInt(v.PO_HDR_PRICE), v.CURRENCY_CODE, v.CREATION_DATE, v.LAST_UPDATE_DATE];

      var sqlQuery = "INSERT INTO PURCHASEORDER_LIST(PO_NUMBER, RELEASES, PO_HEADER_ID, PO_TYPE, VENDOR_NAME, VENDOR_SITE, ITEMS, CONTRACT, REQUESTOR, PO_HDR_PRICE, PO_RELEASE_ID, CURRENCY_CODE, CREATION_DATE, LAST_UPDATE_DATE) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
      var values = [ponumber, releases , poheaderid || null, potype || null, vendorname || null, vendorsite || null, items || null, contract || null, requestor || null, pohdrprice || null, poreleaseid || null, currencycode || null, creationdate || null, lastupdatedate || null];
      // console.log(values + "the return values");
      var result = this.database.executeSql(sqlQuery, values);
    }
    return result;

  }

  // insert the polines

  /**
   * Method to insert polines data into Sqlite database.
   *
   * @param item Item of polines from service.
   */
  insertIntoPolines(item) {
    for (let i = 0; i < item.length; i++) {
      var v = item[i];
      var sqlQuery = "INSERT INTO PURCHASEORDER_ITEMS(LINE_LOCATION_ID, ITEM, SHIPMENT_NUM, LINE_NUM, DESCRIPTION, QUAN_ORD, QUAN_RECV, UOM,RELEASENUM,ORGID,POHEADERID,DELIVERY_DATE) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
      var values = [parseInt(v.LINE_LOCATION_ID), v.ITEM || null, parseInt(v.SHIPMENT_NUM) || null, parseInt(v.LINE_NUM) || null, v.DESCRIPTION || null, v.QUAN_ORD || null, v.QUAN_RECV || null, v.UOM || null, parseInt(v.RELEASE_NUM) || null, parseInt(v.ORG_ID) || null, parseInt(v.PO_HEADER_ID) || null, v.DELIVERY_DATE || null];
      var result = this.database.executeSql(sqlQuery, values);
    }
    console.log(result + "this is the result");
    return result;
  }

  // po item details

  /**
   * Method to insert po itemdetails data to Sqlite database.
   *
   * @param item Object or item from po item details service.
   */
  insertIntoPoItemDetails(item) {
    console.log(item + "this is item details");
    var sqlQuery = "INSERT or REPLACE INTO PO_ITEM_DETAILS(LINE_LOCATION_ID, ITEM, INVENTORY_ITEM_ID, DELIVERY_TO, DESCRIPTION, CATEGORY, ORDER_QTY, SHIPMENT, DESTINATION_TYPE, OVERRIDE, SUBINVENTORY, QUNATITY_RECV, RECEIPT_DATE, PO_HEADER_ID, PO_RELEASE_ID, PO_LINE_ID, PO_DISTRIBUTION_ID, PO_LINE_NUMBER,RELESENUM, SHIP_TO_LOCATION_ID, CURRENCY_CODE, ORG_ID) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    var values = [parseInt(item.LINE_LOCATION_ID) || null, item.ITEM || null, parseInt(item.INVENTORY_ITEM_ID) || null, item.Delivery_to || null, item.DESCRIPTION || null, item.CATEGORY || null, item.Order_Quantity || null, parseInt(item.SHIPMENT) || null, item.DESTINATION_TYPE || null, item.OVERRIDE_STATUS || null, item.SUBINVENTORY || null, item.Quantity_Received || null, item.Receipt_Date || null, parseInt(item.PO_HEADER_ID) || null, parseInt(item.PO_RELEASE_ID) || null, parseInt(item.PO_LINE_ID) || null, parseInt(item.PO_DISTRIBUTION_ID) || null, parseInt(item.PO_LINE_NUMBER) || null, parseInt(item.RELEASE_NUM), parseInt(item.SHIP_TO_LOCATION_ID) || null, item.CURRENCY_CODE || null, parseInt(item.ORG_ID) || null];
    console.log(values);
    return this.database.executeSql(sqlQuery, values);
  }

  /**
   * Method to insert the subinventory data to Sqlite database.
   *
   * @param item Item of subinventory list.
   */
  insertIntoSubInventory(item) {
    let sqlQuery = "INSERT INTO SUBINVENTORY(ORGANIZATION_ID, SUBINVENTORY) VALUES (?,?)";
    let values = [parseInt(item.ORGANIZATION_ID) || null, item.ORGANIZATION_ID || null];
    return this.database.executeSql(sqlQuery, values);
  }

  /**
   * Method to insert the locators list Sqlite database.
   *
   * @param item item of locators list.
   */
  insertIntoLocators(item) {
    let sqlQuery = "INSERT INTO LOCATORS(LOCATOR_LIST,LOCATOR_TYPE) VALUES (?,?)";
    let values = [item.LOCATOR_LIST || null, item.LOCATOR_LIST || null];
    return this.database.executeSql(sqlQuery, values);
  }

  /**
   * Method to insert the lotnumbers to Sqlite database.
   *
   * @param item item for lotnumbers.
   */
  insertIntoLotNumbers(item) {
    let sqlQuery = "INSERT INTO LOTNUMBERS(LOT_NUMBER,LOT_TYPE,LOT_GENERATION) VALUES (?,?,?)";
    let values = [item.LOT_NUMBER || null, item.LOT_TYPE || null, item.LOT_GENERATION || null];
    return this.database.executeSql(sqlQuery, values);
  }

  /**
   * Method to insert the serail number data to Sqlite database.
   *
   * @param item item for serial numbers.
   */
  insertIntoSerialNumbers(item) {
    let sqlQuery = "INSERT INTO SERIALNUMBERS(SERIAL_NUMBER,SERIAL_TYPE) VALUES (?,?)";
    let values = [item.SERIAL_NUMBER || null, item.SERIAL_TYPE || null];
    return this.database.executeSql(sqlQuery, values);
  }

  /**
   * Method to insert operating unit list data to Sqlite database.
   *
   * @param item Items for Operating unit.
   */
  insertIntoOperatingUnit(item) {
    let sqlQuery = "INSERT INTO OPERATINGUNIT(ORG_ID,OPERATING_UNIT_NAME) VALUES (?,?)";
    let values = [item.ORG_ID || null, item.OPERATING_UNIT_NAME || null];
    return this.database.executeSql(sqlQuery, values);
  }

  /**
   * Method to insert inventory organization list to Sqlite database.
   *
   * @param item Items for inventory organization.
   */
  insertIntoInventoryOrg(item) {
    let sqlQuery = "INSERT INTO INVENTORY_ORG(INV_ORG_ID,INVENTORY_ORGANIZATION_NAME) VALUES (?,?)";
    let values = [item.inv_org_id || null, item.INVENTORY_ORGANIZATION_NAME || null];
    return this.database.executeSql(sqlQuery, values);
  }

  /**
   * Method to insert the required receipt details to Sqlite database.
   *
   * @param item Item of receiptdetails that need to be send to service.
   */
  insertIntoReceiptDetails(item) {
    let sqlQuery = "INSERT INTO RECEIPT_ITEM_DETAILS(LINE_LOCATION_ID,DESTINATION,OVERRIDE_STATUS,SUBINVENTORY,QUNATITY_RECV,RECEIPT_DATE,LOCATOR,LOT,MIN_SERIAL,MAX_SERIAL,USERID) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
    let values = [parseInt(item.linelocation) || null, item.destination || null, item.overridestatus || null, item.subinventory || null, item.quantityrec || null, item.receiptdate || null, item.locator || null, item.lot || null, item.min_serial || null, item.max_serial || null, parseInt(item.userid) || null];
    console.log(values);
    return this.database.executeSql(sqlQuery, values);
  }

  // getting the data from the tables
  /**
   * Method to get the data from particular table.
   *
   * @param tableName Tablename for getting the data.
   */
  getList(tableName) {
    let sqlQuery;
    let values = [];
    sqlQuery = `select * from ${tableName}`;
    return this.database.executeSql(sqlQuery, values);

  }

  /**
   * Method to retrieve data of particular lines from database.
   *
   * @param item checked items in items page.
   */
  getReceiptElements(item) {
    console.log(item);
    var csvLines = [];
    var values = [];
    for (var i = 0; i < item.length; i++) {
        csvLines.push(item[i].LINE_LOCATION_ID);
    }
      console.log(csvLines + "for retrieving");
      var inClause = "("+csvLines.toString()+")";
      // inClause = inClause.replace("[","(");
      // inClause = inClause.replace("]",")");

      console.log(inClause+"value of string");
      var sqlQuery = "select PO_ITEM_DETAILS.PO_HEADER_ID,PO_ITEM_DETAILS.RELESENUM,PO_ITEM_DETAILS.LINE_LOCATION_ID,RECEIPT_ITEM_DETAILS.QUNATITY_RECV,RECEIPT_ITEM_DETAILS.DESTINATION,PO_ITEM_DETAILS.ORG_ID,RECEIPT_ITEM_DETAILS.SUBINVENTORY,RECEIPT_ITEM_DETAILS.LOCATOR,RECEIPT_ITEM_DETAILS.LOT,RECEIPT_ITEM_DETAILS.MAX_SERIAL,RECEIPT_ITEM_DETAILS.MIN_SERIAL,RECEIPT_ITEM_DETAILS.RECEIPT_DATE,RECEIPT_ITEM_DETAILS.USERID from ((PURCHASEORDER_ITEMS INNER JOIN PO_ITEM_DETAILS ON PURCHASEORDER_ITEMS.LINE_LOCATION_ID = PO_ITEM_DETAILS.LINE_LOCATION_ID) INNER JOIN RECEIPT_ITEM_DETAILS ON PO_ITEM_DETAILS.LINE_LOCATION_ID=RECEIPT_ITEM_DETAILS.LINE_LOCATION_ID) where PURCHASEORDER_ITEMS.LINE_LOCATION_ID in"+inClause;
      // var sqlQuery = "select * from ((PURCHASEORDER_ITEMS INNER JOIN PO_ITEM_DETAILS ON PURCHASEORDER_ITEMS.LINE_LOCATION_ID = PO_ITEM_DETAILS.LINE_LOCATION_ID) INNER JOIN RECEIPT_ITEM_DETAILS ON PO_ITEM_DETAILS.LINE_LOCATION_ID=RECEIPT_ITEM_DETAILS.LINE_LOCATION_ID) where PURCHASEORDER_ITEMS.LINE_LOCATION_ID="+item[i].LINE_LOCATION_ID;
      console.log(sqlQuery);
      return this.database.executeSql(sqlQuery, values);
  }

  /**
   * Method to delete the records or data of particular table from Sqlite database.
   *
   * @param tableName Table name data that to be deleted.
   * @param item checked or unchecked items.
   */
  deleteList(tableName, item) {
    for (let i = 0; i < item.length; i++) {
      console.log(item[i].LINE_LOCATION_ID + "for deleting");
      var sqlQuery = `delete from ${tableName} where LINE_LOCATION_ID = ?`;
      var values = [item[i].LINE_LOCATION_ID || null];
      var result = this.database.executeSql(sqlQuery, values);
    }
    return result;
  }

  /**
   * Method to update the data of particular table in Sqlite database.
   *
   * @param item data that to be updated.
   */
  updateTable(item){
    var sqlQuery = "UPDATE RECEIPT_ITEM_DETAILS SET (DESTINATION,OVERRIDE_STATUS,SUBINVENTORY,QUNATITY_RECV,RECEIPT_DATE,LOCATOR,LOT,MIN_SERIAL,MAX_SERIAL,USERID ) = (?,?,?,?,?,?,?,?,?,?) where  LINE_LOCATION_ID = ? ";
    var values = [item.destination || null, item.overridestatus || null, item.subinventory || null, item.quantityrec || null, item.receiptdate || null, item.locator || null, item.lot || null, item.min_serial || null, item.max_serial || null, parseInt(item.userid) || null,parseInt(item.linelocation)];
    return this.database.executeSql(sqlQuery, values);
  }

  updatereceipt(quanrec,linelocationid){
    var sqlQuery = "UPDATE RECEIPT_ITEM_DETAILS SET (QUNATITY_RECV ) = (?) where  LINE_LOCATION_ID = ? ";
    var values = [  quanrec || null, parseInt(linelocationid)];
    return this.database.executeSql(sqlQuery, values);
  }

  /**
   * Method to delete the data or recordds of particular table in Sqlite database.
   *
   * @param tableName table name for deleting the data or records.
   */
  deleteListTable(tableName) {
    let values = [];
    var sqlQuery = `delete from ${tableName}`;
    var result = this.database.executeSql(sqlQuery,values);
    return result;
}

/**
 *   Method to get data from Purchase orderitems
 * @param headerid
 */

getLineItemsOffline(headerid){
  let sqlQuery;
  let values = {headerid};
  sqlQuery = "select * from PURCHASEORDER_ITEMS where POHEADERID = ?";
  return this.database.executeSql(sqlQuery, values);
}


/**
 * Method to know the database state.
 */
  getDatabaseState() {
    return this.databaseReady.asObservable();
  }


}

import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';


/*
  Generated class for the FiredbProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
/**
 * Provider to do CRUD operations on Firebase database.
 */
@Injectable()
export class FiredbProvider {

  constructor(public afd: AngularFireDatabase) {
    console.log('Hello FiredbProvider Provider');
  }

  /**
   * Method to get the users list form firebase database.
   */
  getUsers() {
    return this.afd.list('/downloadusers/');
  }

  /**
   * Method to insert the data into firebase database.
   * 
   * @param name Name of the user.
   * @param email Email of user.
   * @param app App name.
   * @param country Country where the user is.
   * @param locality Locality of the user.
   * @param sublocality Sublocality.
   * @param date Date the app is installed.
   * @param device Device the app is installed.
   */
  addUser(name,email,app,country,locality,sublocality,date,device) {
    this.afd.list('/downloadusers/').push({name,email,app,country,locality,sublocality,date,device});
  }

}

/**
 * Interface showing the lineitems array.
 */
export interface Sample{
  LINE_ITEMS : string [];
}

/**
 * Interface for having account.
 */
export interface Account{
  username: String;
  password: String;
}

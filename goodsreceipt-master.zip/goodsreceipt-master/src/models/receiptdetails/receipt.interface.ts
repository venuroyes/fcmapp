/**
 * Interface for the receipt details that are to be sent to service.
 */
export interface ReceiptDetails {
  linelocation: number;
  destination: String,
  overridestatus: String,
  subinventory: String,
  quantityrec: String,
  receiptdate: String,
  locator: String,
  lot: String,
  min_serial: String,
  max_serial: String,
  userid: number,
}

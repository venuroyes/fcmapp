import { DataProvider } from './../../providers/data/data';
import { Component, ViewChild, OnInit, Renderer, Input } from '@angular/core';

/**
 * Generated class for the AccordionComponent component.
 *
 * AccordionComponent class to get the faq's from the local file.
 * 
 * See https://angular.io/docs/ts/latest/api/core/index/ComponentMetadata-class.html
 * for more info on Angular Components.
 */
@Component({
  selector: 'accordion',
  templateUrl: 'accordion.html'
})
export class AccordionComponent implements OnInit{
  /**
   * Value for component expansion.
   */
  accordionExpanded =  false;
  /**
   * Value for faq's.
   */
  faq: any;
  @ViewChild("cc") cardContent: any;
  @Input("title") faqdata: {};
  /**
   * Value for icon displayed.
   */
  icon: string = "arrow-forward";
  constructor(public renderer: Renderer, private data: DataProvider) {
    console.log(this.faqdata);
  }

  /**
   * Method for toggling the accordion component.
   */
  toggleAccordion() {
    if(this.accordionExpanded){
      this.renderer.setElementStyle(this.cardContent.nativeElement, "max-height", "0px");
      this.renderer.setElementStyle(this.cardContent.nativeElement, "padding", "0px 16px");
    }else{
      this.renderer.setElementStyle(this.cardContent.nativeElement, "max-height", "500px");
      this.renderer.setElementStyle(this.cardContent.nativeElement, "padding", "16px 16px");
    }
    this.accordionExpanded = !this.accordionExpanded;
    this.icon = this.icon == "arrow-forward" ? "arrow-down" : "arrow-forward";
  }

  /**
   * Method invoked when the page is loaded.
   */
  ngOnInit(): void {
    console.log(this.cardContent.nativeElement);
    this.renderer.setElementStyle(this.cardContent.nativeElement,"webkitTransition","max-height 100ms, padding 100ms");
  }

}

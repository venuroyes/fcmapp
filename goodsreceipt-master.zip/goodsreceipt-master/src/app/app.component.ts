import { HelpPage } from './../pages/help/help';
import { FormPage } from './../pages/form/form';
import { SingletonProvider } from './../providers/singleton/singleton';
import { DatabaseProvider } from './../providers/database/database';
import { DataProvider } from './../providers/data/data';
import { GlobalvariablesProvider } from './../providers/globalvariables/globalvariables';
import { NetworkProvider } from './../providers/network/network';
import { LoginPage } from './../pages/login/login';
import { Component, ViewChild } from '@angular/core';
import { Nav, Platform, AlertController,LoadingController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Storage } from '@ionic/storage';
import { AppRate } from '@ionic-native/app-rate';

/**
 * MyApp class is the main class that is for the starting of the application.
 */

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  /**
   * Value for rootpage to be displayed.
   */
  rootPage: any = LoginPage;

  pages: Array<{ title: string, component: any }>;

  constructor(public platform: Platform, public storage: Storage, public alertCtrl: AlertController, public statusBar: StatusBar, public splashScreen: SplashScreen, private networkprovider: NetworkProvider, private dataprovider: DataProvider, private singleton: SingletonProvider, public globalvars: GlobalvariablesProvider, private databaseprovider: DatabaseProvider, private appRate: AppRate,public loadCtrl:LoadingController) {
   /**
    * Checks whether app is online or offline.
    */
    if (this.networkprovider.isOnline()) {
      this.initializeApp();
    } else {
      console.log("Disconnected");
      let alert = this.alertCtrl.create({
        title: 'Please connect to network',
        buttons: [
          {
            text: "ok"
          }
        ]

      });
      alert.present();

    }

  }

  /**
   * Method to initialize the application.
   */
  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need
      /**
       * Check the value of introShown in the storage.
       */
      this.storage.get('introShown').then((result) => {

              //  if(result){
                 this.rootPage = LoginPage;
              //  } else {
                //  this.rootPage = FormPage;
                //  this.storage.set('introShown', true);
              //  }
             });
      this.statusBar.styleDefault();
      this.splashScreen.hide();

    });
    console.log(this.globalvars.getShowForm()+"value stores");
    // if(this.globalvars.getShowForm() === "1" || this.globalvars.getShowForm() === 1){
                //  this.rootPage = LoginPage;
    //            } else {
    //              this.rootPage = FormPage;
    //              this.globalvars.setShowForm("1");
    //            }
  }

  /**
   * Method to go to helppage.
   */
  help() {
    this.nav.push(HelpPage);
  }

  /**
   * Method to logout form the application.
   */
  logout() {
    let   loading = this.loadCtrl.create({
      content: 'Please wait...'
    });
    loading.present();
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    // set certain preferences
    /**
     * To show the app rate alert when the user logged out.
     */
    // this.appRate.preferences.storeAppURL = {
    //   ios: 'com.algarytm.goodsreceipt.app',
    //   android: 'market://details?id=com.algarytm.goodsreceipt.app',
    // };
    // this.appRate.preferences.promptAgainForEachNewVersion = false;
    // this.appRate.preferences.callbacks = {
    //   onButtonClicked(buttonIndex){
    //     console.log("On button clicked"+buttonIndex);
    //     // this.storage.set('rate', '1');
    //   }
    // }
    // this.appRate.promptForRating(true);
    // this.storage.get('rate').then((res) => {
    //   console.log(res+"rated");
    //   if(res === '1'){
    //     this.appRate.promptForRating(false);
    //   }else{
    //     this.appRate.promptForRating(true);
    //   }

    // })
    if (this.globalvars.getDemo() === "1" || this.globalvars.getDemo() === 1) {
      this.globalvars.setDemo("0");
      this.globalvars.setUserFullName("");
      this.nav.setRoot(LoginPage);
    } else {
      console.log(this.globalvars.getUserFullName());
      /**
       * Rest service for logout.
       */
      let logoutURL = this.singleton.logoutUrl;
      // let body = {
      //   "P_USER_NAME": this.globalvars.getUsername()
      // }
      /**
       * Request body for logout rest service to get the data.
       */
      let body = {
        "SECURITY_UTIL":
        {
          "@xmlns": "http://xmlns.oracle.com/apps/fnd/rest/SECURITY_UTIL/logout_user_f/",
          "RESTHeader":
          {
            "xmlns": "http://xmlns.oracle.com/apps/fnd/rest/SECURITY_UTIL/header",
            "Responsibility": "SYSTEM_ADMINISTRATOR",
            "RespApplication": "SYSADMIN",
            "SecurityGroup": "STANDARD",
            "NLSLanguage": "AMERICAN",
            "Org_Id": "7911"
          },
          "InputParameters":
          {
            "P_USER_NAME": this.globalvars.getUsername()
          }
        }
      }
      console.log(body);
      /**
       * Calling of logout rest service using dataprovider getdata method.
       */
      this.dataprovider.getData(logoutURL, body).subscribe(data => {

        console.log(data);
        let dataString = data.OutputParameters.LOGOUT_USER_F;
        if (typeof dataString === 'object') {

        } else {
          let result = JSON.parse(dataString);
          if (result.data[0].STATUS === 1 || result.data[0].STATUS === "1") {
            this.globalvars.setDemo("0");
            this.globalvars.setUserFullName("");
            this.globalvars.setUsername("");
            this.globalvars.setUserId("0");
            this.nav.setRoot(LoginPage);
          }
        }
      });

    }
 loading.dismiss();
  }

}

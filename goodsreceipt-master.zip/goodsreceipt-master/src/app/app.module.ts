import { InventoryPage } from './../pages/inventory/inventory';
import { ReceivingPage } from './../pages/receiving/receiving';
import { HelpPage } from './../pages/help/help';
import { FormPage } from './../pages/form/form';
import { ReceiptsPage } from './../pages/receipts/receipts';
import { SelectmodalPage } from './../pages/selectmodal/selectmodal';
import { PosettingsPage } from './../pages/posettings/posettings';
import { PoitemdetailPage } from './../pages/poitemdetail/poitemdetail';
import { PoitemsPage } from './../pages/poitems/poitems';
import { PolistPage } from './../pages/polist/polist';
import { LoginPage } from './../pages/login/login';
import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { HttpModule } from "@angular/http";
import { MyApp } from './app.component';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { DataProvider } from '../providers/data/data';
import { GlobalvariablesProvider } from '../providers/globalvariables/globalvariables';
import { SingletonProvider } from '../providers/singleton/singleton';
import { DatabaseProvider } from '../providers/database/database';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';
import { IonicStorageModule } from "@ionic/storage";
import { SQLitePorter } from "@ionic-native/sqlite-porter";
import { Keyboard } from '@ionic-native/keyboard';
import { Network } from '@ionic-native/network';
import { NetworkProvider } from '../providers/network/network';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';
import { DatePicker } from '@ionic-native/date-picker';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';
import { DatePipe } from '@angular/common';
import { FiredbProvider } from '../providers/firedb/firedb';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { AngularFireModule } from 'angularfire2';
import { AccordionComponent } from '../components/accordion/accordion';
import { SMS } from '@ionic-native/sms';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio';
import { InAppBrowser } from '@ionic-native/in-app-browser';
import { AppRate } from '@ionic-native/app-rate';
import { Geolocation } from '@ionic-native/geolocation';
import { NativeGeocoder } from '@ionic-native/native-geocoder';
import { LocationAccuracy } from '@ionic-native/location-accuracy';
import { SampleProvider } from '../providers/sample/sample';

/**
 * Firebaseconfig is the constant having the data or keys related to firebase database.
 */
export const firebaseConfig = {
  apiKey: "AIzaSyDNSQzpP04NhO_mHv6G2EyQGbjQU_Ch9pU",
  authDomain: "formsapp-a091f.firebaseapp.com",
  databaseURL: "https://formsapp-a091f.firebaseio.com",
  projectId: "formsapp-a091f",
  storageBucket: "",
  messagingSenderId: "174297613742"
};

@NgModule({
  declarations: [
    MyApp,
    LoginPage,
    PolistPage,
    PoitemsPage,
    PoitemdetailPage,
    PosettingsPage,
    SelectmodalPage,
    ReceiptsPage,
    FormPage,
    HelpPage,
    AccordionComponent,
    InventoryPage,
    ReceivingPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    HttpModule,
    IonicStorageModule.forRoot(),
    AngularFireDatabaseModule,
    AngularFireModule.initializeApp(firebaseConfig),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    LoginPage,
    PolistPage,
    PoitemsPage,
    PoitemdetailPage,
    PosettingsPage,
    SelectmodalPage,
    ReceiptsPage,
    FormPage,
    HelpPage,
    ReceivingPage,
    InventoryPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    DataProvider,
    GlobalvariablesProvider,
    SingletonProvider,
    DatePipe,
    DatabaseProvider,
    SQLite,
    SQLitePorter,
    Keyboard,
    Network,
    NetworkProvider,
    BarcodeScanner,
    DatePicker,
    File,
    FileTransfer,
    FileTransferObject,
    FiredbProvider,
    SMS,
    FingerprintAIO,
    InAppBrowser,
    AppRate,
    FiredbProvider,
    Geolocation,
    NativeGeocoder,
    LocationAccuracy,
    SampleProvider,
  ]
})
export class AppModule {}

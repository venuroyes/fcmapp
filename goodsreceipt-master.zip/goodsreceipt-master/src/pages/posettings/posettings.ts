import { PolistPage } from '../polist/polist';
import { SingletonProvider } from './../../providers/singleton/singleton';
import { DataProvider } from './../../providers/data/data';
import { GlobalvariablesProvider } from './../../providers/globalvariables/globalvariables';
import { Component } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
import { DatePicker } from '@ionic-native/date-picker';

/**
 * Generated class for the PosettingsPage page.
 *
 * PosettingsPage class to get the operating unit and inventory organization list for selecting.
 * 
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-posettings',
  templateUrl: 'posettings.html',
})
export class PosettingsPage {
  /**
   * Value for operating unit list.
   */
  operatingUnitList: any;
  /**
   * Value for operating unit.
   */
  operatingunit: any;
  /**
   * Value for inventory organization list.
   */
  inventoryOrgList: any;
  /**
   * Value for need date.
   */
  needDate: any;
  /**
   * Value for inventory.
   */
  inventory: any;
  //  selectOptions:any;
  constructor(public navCtrl: NavController, private datePicker: DatePicker, public navParams: NavParams, private singleton: SingletonProvider, private globalvars: GlobalvariablesProvider, private data: DataProvider, public alertCtrl: AlertController) {
    /**
     * Check whether the app is running in demo mode or normal mode.
     */
    if (this.globalvars.getDemo() === "1" || this.globalvars.getDemo() === 1) {
        this.loadDemoOperatingList();
        this.loadDemoInventoryList();
    } else {
      // this.setPolist();
      this.operatingunit = "7911";
      if (this.operatingunit == undefined || this.operatingunit == "") {
        this.loadOperatingList();
      } else {
        this.loadOperatingList();
        this.loadOrganizationList();
        this.inventory = "7914";
      }
    }
  }

  /**
   * Method invoked when the page is loaded.
   */
  ionViewDidLoad() {
    console.log('ionViewDidLoad PosettingsPage');
  }

  //method to get the operating list

  /**
   * Methos to get the operating unit list.
   */
  loadOperatingList() {
    /**
     * Rest service for operating unit list.
     */
    let operatingListUrl = this.singleton.operatingUnitList;
    // let body={

    // };

    /**
     * Request body for operating unit list rest service.
     */
    let body = {
      "INV_OULIST":
      {
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/INV_OULIST/get_org_id_f/",
        "RESTHeader": {
          "xmlns": "http://xmlns.oracle.com/apps/fnd/rest/INV_OULIST/header",
          "Responsibility": "SYSTEM_ADMINISTRATOR",
          "RespApplication": "SYSADMIN",
          "SecurityGroup": "STANDARD",
          "NLSLanguage": "AMERICAN",
          "Org_Id": "7911"
        },
        "InputParameters":
        {

        }
      }
    }

    /**
     * Calling of operating unit list rest service using data provider getiinventorydata method.
     */
    this.data.getInventoryData(operatingListUrl, body).subscribe(data => {
      console.log(data);

      
      /**
       * taking the value of the string and convert to JSON Object
       */
      let dataString = data.OutputParameters.GET_ORG_ID_F;
      console.log(dataString);
      if (typeof dataString === 'object') {

      } else {
        let resultList = JSON.parse(dataString);
        console.log(resultList.data);
        this.operatingUnitList = resultList.data;
        console.log(this.operatingUnitList);
      }
    })
  }

  /**
   * Method to get the inventory organization list from the service.
   */
  loadOrganizationList() {
    /**
     * Rest service for inventory organization list.
     */
    let inventoryListUrl = this.singleton.inventoryOrgList;
    /**
     * Request body for inventory organization list rest service.
     */
    let orgid = {
      "INV_ORGN":
      {
        "@xmlns": "http://xmlns.oracle.com/apps/ar/rest/INV_ORGN/get_organization_f/",
        "RESTHeader":
        {
          "xmlns": "http://xmlns.oracle.com/apps/ar/rest/INV_ORGN/get_cm_hdr_dtls_p/",
          "Responsibility": "SYSTEM_ADMINISTRATOR",
          "RespApplication": "SYSADMIN",
          "SecurityGroup": "STANDARD",
          "NLSLanguage": "AMERICAN",
          "Org_Id": "7911"
        },
        "InputParameters":
        {
          "P_ORG_ID": "7911"
        }
      }
    }

    /**
     * Calling of inventory organization list rest service using data provider getinventorydata method.
     */
    this.data.getInventoryData(inventoryListUrl, orgid).subscribe(data => {
      console.log(data);
      // taking the value of the string and convert to JSON Object
      let dataString = data.OutputParameters.GET_ORGANIZATION_F;
      console.log(dataString);
      if (typeof dataString === 'object') {

      } else {
        let resultList = JSON.parse(dataString);
        console.log(resultList.data);
        this.inventoryOrgList = resultList.data;
        console.log(this.inventoryOrgList);
      }
    })
  }

  // method to get inventary organization list

  /**
   * Method to get the inventory organization list using operating unit value.
   * 
   * @param id selected operating unit.
   */
  loadInventoryList(id) {
    /**
     * Rest service for inv org list.
     */
    let inventoryListUrl = this.singleton.inventoryOrgList;
    /**
     * Request body for the inv org list restservice.
     */
    let orgid = {
      "INV_ORGN":
      {
        "@xmlns": "http://xmlns.oracle.com/apps/ar/rest/INV_ORGN/get_organization_f/",
        "RESTHeader":
        {
          "xmlns": "http://xmlns.oracle.com/apps/ar/rest/INV_ORGN/get_cm_hdr_dtls_p/",
          "Responsibility": "SYSTEM_ADMINISTRATOR",
          "RespApplication": "SYSADMIN",
          "SecurityGroup": "STANDARD",
          "NLSLanguage": "AMERICAN",
          "Org_Id": "7911"
        },
        "InputParameters":
        {
          "P_ORG_ID": id
        }
      }
    }

    /**
     * Calling of rest service using dataprovider getInventoryData method.
     */
    this.data.getInventoryData(inventoryListUrl, orgid).subscribe(data => {
      console.log(data);
      // taking the value of the string and convert to JSON Object
      let dataString = data.OutputParameters.GET_ORGANIZATION_F;
      console.log(dataString);
      if (typeof dataString === 'object') {

      } else {
        let resultList = JSON.parse(dataString);
        console.log(resultList.data);
        this.inventoryOrgList = resultList.data;
        console.log(this.inventoryOrgList);
      }
    })
  }
  //to get the selected value from the select
  /**
   * Method to get the operating usnit value and get the inv org list.
   * 
   * @param operatingunit operating unit value.
   */
  onChange(operatingunit) {
    console.log(operatingunit);

    if (this.globalvars.getDemo() === "1" || this.globalvars.getDemo() === 1) {
      this.loadDemoInventoryList();
    } else {
      this.loadInventoryList(operatingunit);
    }
  }

  /**
   * Method to get the inventory organization value.
   * 
   * @param inventory inv org value.
   */
  onChangeInvt(inventory) {
    console.log(inventory);
  }
  // to store the data in globalvariables to use it in other page
  /**
   * Method to check the values selected from the dropdowns
   * 
   * and set them to the global variables for furthur use.
   */
  saveData() {

    if (this.operatingunit === "" || this.inventory === "") {
      let alert = this.alertCtrl.create({
        title: "Please select the values",
        buttons: [
          {
            text: "ok",
          }
        ]

      });
      alert.present();

    } else {
      console.log(this.operatingunit + "operating unit");
      console.log(this.inventory + "inventory org")
      this.globalvars.setOrgId(this.operatingunit);
      this.globalvars.setInvOrgId(this.inventory);
      this.globalvars.setDeliveryDate(this.needDate);
      this.navCtrl.setRoot(PolistPage);
    }
  }

  /**
   * Method to show date picker.
   */
  showDatePicker() {
    this.datePicker.show({
      date: new Date(),
      mode: 'date',
      allowOldDates: false,
      androidTheme: this.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_DARK,
    }).then(
      date => this.needDate = date.toISOString().slice(0, 10),
      err => console.log('Error occurred while getting date: ', err)
      );
  }

  // demo operating list
  /**
   * Method to get the operating unit data from local file for demo mode.
   */
  loadDemoOperatingList() {
    this.data.getSubInventoryJsonData().subscribe(data => {
      console.log(data);
      this.operatingUnitList = data.OPERATING_UNIT;
      console.log(this.operatingUnitList);
    });

  }

  // demo inventory organization list
   /**
   * Method to get the inventory organization data from local file for demo mode.
   */
  loadDemoInventoryList() {
    this.data.getSubInventoryJsonData().subscribe(data => {
      console.log(data);
      this.inventoryOrgList = data.INVENTORY_ORGANIZATION;
      console.log(this.operatingUnitList);
    });
  }

}

import { Storage } from '@ionic/storage';
import { FormPage } from './../form/form';
import { HelpPage } from './../help/help';
import { DatabaseProvider } from './../../providers/database/database';
import { DataProvider } from './../../providers/data/data';
import { SingletonProvider } from './../../providers/singleton/singleton';
import { Account } from './../../models/account/account.interface';
import { GlobalvariablesProvider } from './../../providers/globalvariables/globalvariables';
import { SampleProvider } from "../../providers/sample/sample";
import { PolistPage } from './../polist/polist';
import { Component, OnInit } from '@angular/core';
import { NavController, NavParams, AlertController, Platform, MenuController, LoadingController } from 'ionic-angular';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio';


/**
 * Generated class for the LoginPage page.
 *
 * LoginPage class to check the login details entered by the user.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

/**
 * Value for the account for the form.
 */
  account = {} as Account;
  /**
   * Value for save credentials check box.
   */
  savecred: any;
  /**
   * Value for assinging the check box value.
   */
  savecredentials: any;
  /**
   * Value for the users.
   */
  users = [];
  /**
   * Value for the fingerprint.
   */
  fingerPresent = false;
  /**
   * Value for loading controller.
   */
  loading = this.loadCtrl.create({
    content: 'Please wait...'
  });
  /**
   * Value for enablig the finger print.
   */
  enabledFingerprint = false;

  constructor(private sample: SampleProvider,public navCtrl: NavController,public platform: Platform, public menu: MenuController, private faio: FingerprintAIO, private storage: Storage,public navParams: NavParams, private globalvars: GlobalvariablesProvider, private dataprovider: DataProvider, private singleton: SingletonProvider, public alertCtrl: AlertController, private databaseprovider: DatabaseProvider,public loadCtrl: LoadingController) {
    this.menu.swipeEnable(false);
   this.account.username = '';
    this.account.password = '';
  }

  ngOnInit(){

  }

  /**
   * Method invoked when page is loaded.
   */
  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
    /**
     * Check whether the fingerprint is present or not
     */
    this.faio.isAvailable().then(res => {
      console.log("this is finger print res" + res);
      if (res === "finger") {
        this.enabledFingerprint = true;
      } else {
        this.enabledFingerprint = false;
      }
    })

    /**
     * To check the value savecredentials in the storage.
     */
    this.storage.get('savecredentials').then((result) => {

      if (result) {
        console.log("saved the credentilas" + result);
        /**
         * Value to get the user details from the sqlite database.
         */
        this.databaseprovider.getList("USER_DETAILS").then(res => {
          console.log(res);
          if (res.rows.length > 0) {
            for (var i = 0; i < res.rows.length; i++) {
              // this.users.push({userid: res.rows.item(i).USERID,personid: res.rows.item(i).PERSONID, username: res.rows.item(i).USERNAME, fullname: res.rows.item(i).FULLNAME, status: res.rows.item(i).STATUS});
              this.users.push(res.rows.item(i));
            }
          }
          if (this.users.length > 0) {
            for (var j = 0; j < this.users.length; j++) {
              this.account.username = this.users[j].USERNAME;
              this.account.password = this.users[j].PASSWORD;
              this.savecredentials = true;
              this.savecred = true;
            }
          } else {
            console.log("There are no users");
          }
          console.log(this.users);
        })
      } else {
        console.log("not saved the credentilas" + result);
        this.account.username = "";
        this.account.password = "";
        this.savecred = false;
      }
    });
    console.log('ionViewDidLoad LoginPage');
    /**
     * To check the fingerprint value in the storage.
     */
    this.storage.get('fingerprint').then((result) => {

            if (result) {
              console.log("saved the fingerprint" + result);
              /**
               * To show the finger print authentication.
               */
              this.faio.show({
                clientId: 'Goods Receipt',
                clientSecret: 'password', //Only necessary for Android
                disableBackup: true,
                localizedFallbackTitle: 'Use Pin', //Only for iOS
                localizedReason: 'Please authenticate' //Only for iOS
              })
                .then((result: any) => {
                  console.log(result);
                  this.enabledFingerprint = false;
                  this.getUser();
                })
                .catch((error: any) => {
                  console.log(error)
                });
            } else {
              console.log("this is fingerprint storege");
            }
    });
  }

    fingerprint(){
    this.faio.isAvailable().then(res => {
      console.log("this is finger print res" + res);
      if (res === "finger") {
        this.enabledFingerprint = true;
      } else {
        this.enabledFingerprint = false;
      }
    })

    /**
     * To check the value savecredentials in the storage.
     */
    this.storage.get('savecredentials').then((result) => {

      if (result) {
        console.log("saved the credentilas" + result);
        /**
         * Value to get the user details from the sqlite database.
         */
        this.databaseprovider.getList("USER_DETAILS").then(res => {
          console.log(res);
          if (res.rows.length > 0) {
            for (var i = 0; i < res.rows.length; i++) {
              // this.users.push({userid: res.rows.item(i).USERID,personid: res.rows.item(i).PERSONID, username: res.rows.item(i).USERNAME, fullname: res.rows.item(i).FULLNAME, status: res.rows.item(i).STATUS});
              this.users.push(res.rows.item(i));
            }
          }
          if (this.users.length > 0) {
            for (var j = 0; j < this.users.length; j++) {
              this.account.username = this.users[j].USERNAME;
              this.account.password = this.users[j].PASSWORD;
              this.savecredentials = true;
              this.savecred = true;
            }
          } else {
            console.log("There are no users");
          }
          console.log(this.users);
        })
      } else {
        console.log("not saved the credentilas" + result);
        this.account.username = "";
        this.account.password = "";
        this.savecred = false;
      }
    });
    console.log('ionViewDidLoad LoginPage');
    /**
     * To check the fingerprint value in the storage.
     */
    this.storage.get('fingerprint').then((result) => {

            if (result) {
              console.log("saved the fingerprint" + result);
              /**
               * To show the finger print authentication.
               */
              this.faio.show({
                clientId: 'Goods Receipt',
                clientSecret: 'password', //Only necessary for Android
                disableBackup: true,
                localizedFallbackTitle: 'Use Pin', //Only for iOS
                localizedReason: 'Please authenticate' //Only for iOS
              })
                .then((result: any) => {
                  console.log(result);
                  this.enabledFingerprint = false;
                  this.getUser();
                })
                .catch((error: any) => {
                  console.log(error)
                });
            } else {
              console.log("this is fingerprint storege");
            }
    });
  }

  /**
   * Method to get the user details form Sqlite database.
   */
  getUser() {
    this.databaseprovider.getList("USER_DETAILS").then(res => {
      console.log(res);
      if (res.rows.length > 0) {
        for (var i = 0; i < res.rows.length; i++) {
          // this.users.push({userid: res.rows.item(i).USERID,personid: res.rows.item(i).PERSONID, username: res.rows.item(i).USERNAME, fullname: res.rows.item(i).FULLNAME, status: res.rows.item(i).STATUS});
          this.users.push(res.rows.item(i));
        }
      }
      if (this.users.length > 0) {
        for (var j = 0; j < this.users.length; j++) {
          this.account.username = this.users[j].USERNAME;
          this.account.password = this.users[j].PASSWORD;
        }
        console.log(this.account.username + "username" + this.account.password);
        this.login();
      } else {
        console.log("There are no users");
        // this.fingerPresent = false;
      }
      console.log(this.users);
    })
  }

  /**
   * Method to get the checkbox value and set to save credentials.
   *
   * @param cred Value of the checkbox.
   */
  setValue(cred) {
    console.log("cred" + cred);
    this.savecredentials = cred;
    this.savecred = cred;
  }


  //method when login button clicked
  /**
   * Method to check the login credentials entered by the user.
   */
  login() {
    this.loading.present();
    if (this.account.username === "") {
      this.sample.userAlert();
      this.loading.dismiss();
      return false;
    }
    if (this.account.password === "") {
      this.sample.passwordAlert();
      this.loading.dismiss();
      return false;
    }

    if (this.account.username !== "" && this.account.password !== "") {
    /**
     * Request body for login rest service.
     */
    let userdata = {
      "INV_PO_LOGIN":
      {
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/INV_PO_LOGIN/get_login_status_f/",
        "RESTHeader": {
          "xmlns": "http://xmlns.oracle.com/apps/fnd/rest/INV_PO_LOGIN/header",
          "Responsibility": "SYSTEM_ADMINISTRATOR",
          "RespApplication": "SYSADMIN",
          "SecurityGroup": "STANDARD",
          "NLSLanguage": "AMERICAN",
          "Org_Id": "7911"
        },
        "InputParameters":
        {
          "P_USER_NAME": this.account.username,
          "P_PASSWORD": this.account.password
        }
      }
    }

    /**
     * Rest service for login.
     */
    let loginUrl = this.singleton.loginUrl;

    // calling the data provider to login
    /**
     * Calling of login rest service using dataprovider getcommondata method.
     */
    this.dataprovider.getCommonData(loginUrl, userdata).subscribe(data => {
      console.log(data);
      this.loading.dismiss();
      // taking the value of the string and convert to JSON Object
      let dataString = data.OutputParameters.GET_LOGIN_STATUS_F;
      console.log(dataString);
      console.log("This is the error");
      if (typeof dataString === 'object') {
        console.log("Hi this is if");
      }
      else {
        let loginResult = JSON.parse(dataString);
        console.log(loginResult.data[0].STATUS);
        if (loginResult.data[0].STATUS == '1' || loginResult.data[0].STATUS == 1) {
          this.globalvars.setDemo("0");
          this.globalvars.setUserFullName(loginResult.data[0].FULL_NAME);
          this.globalvars.setUserId(loginResult.data[0].PERSON_ID);
          this.globalvars.setUsername(loginResult.data[0].USER_NAME);
          this.navCtrl.setRoot(PolistPage);
          /**
           * To check the value of savecred and if true insert data into database.
           */
          if (this.savecred == true) {
            console.log("entered something");
            this.databaseprovider.deleteListTable('USER_DETAILS').then(deleted => {
              console.log("deleted row" + deleted);
              this.databaseprovider.insertIntoUserDetails(loginResult.data[0], this.account.password).then(res => {
                console.log(res);
                this.storage.set('savecredentials', true);
              }), (error) => {
                console.log("error while inserting" + error);
              }
            }), (err) => {
              console.log("error while deleting" + err);
            }
          } else {
            console.log("not true");
            this.storage.set('savecredentials', false);
          }
          /**
           * To check the value of enabledFingerprint and if true insert data into database.
           */
          if (this.enabledFingerprint == true) {
            this.databaseprovider.deleteListTable('USER_DETAILS').then(deleted => {
              console.log("deleted row" + deleted);
              this.databaseprovider.insertIntoUserDetails(loginResult.data[0], this.account.password).then(res => {
                console.log(res);
                this.storage.set("fingerprint", true);
              }), (error) => {
                console.log("error while inserting" + error);
              }
            }), (err) => {
              console.log("error while deleting" + err);
              this.storage.set("fingerprint", false);
            }
          } else {
            console.log("there si no finger print enabled");
          }

          /**
           * To check values of both enabledFingerprint and savecred.
           */
          if (this.enabledFingerprint == true && this.savecred == true) {
            this.databaseprovider.deleteListTable('USER_DETAILS').then(deleted => {
              console.log("deleted row" + deleted);
              this.databaseprovider.insertIntoUserDetails(loginResult.data[0], this.account.password).then(res => {
                console.log(res);
                this.storage.set('savecredentials', true);
              }), (error) => {
                console.log("error while inserting" + error);
              }
            }), (err) => {
              console.log("error while deleting" + err);
            }
          } else {
            console.log("this is both finger print and save");
            this.storage.set('savecredentials', false);
          }

          console.log(this.account.username);
        } else if (loginResult.data[0].STATUS == '0' || loginResult.data[0].STATUS == 0) {
          let alert = this.alertCtrl.create({
            title: loginResult.data[0].ERROR,
            buttons: [
              {
                text: "ok",
                handler: () => {
                  this.loading.dismiss();
                }

              }
            ]

          });
          return alert.present();

        } else if (loginResult.data[0].STATUS == '2' || loginResult.data[0].STATUS == 2) {
          let alert = this.alertCtrl.create({
            title: loginResult.data[0].ERROR,
            buttons: [
              {
                text: "ok",
                handler: () => {
                  this.loading.dismiss();
                }

              }
            ]

          });
          return alert.present();

        } else {
          console.log('error');
        }
      }
    })
  }
  }

  /**
   * Method to get data from local json file for demo mode of the app.
   */
  // go to demo mode of the application
  goToDemo() {
    this.globalvars.setDemo("1");
    this.navCtrl.setRoot(PolistPage);
    this.globalvars.setUserFullName("JOHN, CARTER");
  }

  /**
   * Method to go to next page.
   */
  loginSql() {
    this.navCtrl.setRoot(PolistPage);
  }

 /**
  * Method to go to helppage.
  */
  helppage() {
    this.navCtrl.push(HelpPage);
  }

  /**
   * Method to show alert with particular message.
   */
  showMsg(){
    let msg = "App needs PLSQL code to connect to EBS.Our Mobile team will be in touch with you.Try demo version to get similar experience";
    let alert = this.alertCtrl.create({
      title: msg,
      buttons: [
        {
          text: "ok",
          // handler: () => {
          //   this.navCtrl.setRoot
          // }

        }
      ]

    });
    return alert.present();
  }

  fingerprintLogin() {
    this.faio.isAvailable().then(res => {
      console.log("result" + res);
      if(res === "finger"){
        console.log(this.account.username+"user"+this.account.password);
        this.faio.show({
          clientId: 'Goods Receipt',
          clientSecret: 'password', //Only necessary for Android
          disableBackup:true,
      })
      .then((result: any) => {
        console.log(result);
        this.login();
        this.navCtrl.setRoot(PolistPage);
      })
      .catch((error: any) => {
        console.log(error)
      });
      }else{
        let msg = "There is no finger print option";
        let alert = this.alertCtrl.create({
          title: msg,
          buttons: [
            {
              text: "ok",
            }
          ]

        });
        return alert.present();
      }
    }).catch(err => {
      console.log("error"+err);
    })
  }

}

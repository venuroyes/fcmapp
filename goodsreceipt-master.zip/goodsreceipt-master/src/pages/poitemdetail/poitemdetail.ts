import { ReceiptDetails } from './../../models/receiptdetails/receipt.interface';
import { PoitemsPage } from './../poitems/poitems';
import{ ReceivingPage} from './../receiving/receiving';
import { InventoryPage} from './../inventory/inventory';
import { DatabaseProvider } from './../../providers/database/database';
import { DataProvider } from './../../providers/data/data';
import { SingletonProvider } from './../../providers/singleton/singleton';
import { GlobalvariablesProvider } from './../../providers/globalvariables/globalvariables';
import { SelectmodalPage } from './../selectmodal/selectmodal';
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ModalController, ViewController, AlertController, LoadingController } from 'ionic-angular';
import { DatePipe } from '@angular/common';
import { IfObservable } from 'rxjs/observable/IfObservable';
import { PolistPage } from './../polist/polist';
import { File } from '@ionic-native/file';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
/**
 * Generated class for the PoitemdetailPage page.
 *
 * PoitemdetailPage class to get the poitem details from the rest service.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-poitemdetail',
  templateUrl: 'poitemdetail.html',
  providers: [DatePipe]
})
export class PoitemdetailPage {
  /**
   * value for receipt details.
   */
  receiptDetails = {} as ReceiptDetails;
  /**
   * Value for default subinventory.
   */
  defaultSubInventory: string;
  /**
   * Value for suninventory.
   */
  subInventory: string;
  /**
   * Value for locators.
   */
  locators: any;
  /**
   * Value for lotnumber.
   */
  lotnumber: any;
  /**
   * Value for minserial number.
   */
  minserialnumber: any;
  /**
   * Value for maxserial number.
   */
  maxserialnumber: any;
  /**
   * Value for posubitemdetials from previous page.
   */
  poSubItemDetails: any;
  /**
   * Value for poitemdetails.
   */
  poItemDetails:any;

  /**
   * Value for polineid.
   */
  poLineId: any;
  /**
   * Value for polinelocationid.
   */
  poLineLocationId: any;
  /**
   * Value for details linelocationid.
   */
  detailsLineLocationId: any;
  /**
   * Value for receivedby.
   */
  receivedBy: string;
  /**
   * Value for received Quantity.
   */
  receivedQty: any;
  /**
   * Value for destination type.
   */
  destinationType: string;
  /**
   * Value for override.
   */
  override: string;
  /**
   * Value for inventory item id.
   */
  inventoryItemId: any;
  /**
   * Value for subinventory list.
   */
  subinventoryList: any;
  /**
   * Value for locators list.
   */
  locatorsList: any;
  /**
   * Value for locator type.
   */
  locatorType: string;
  /**
   * Value for lotnumber list.
   */
  lotNumbersList: any;
  /**
   * Value for lottype.
   */
  lotType: string;
  /**
   * Value for lot generation.
   */
  lotGeneration: any;
  /**
   * Value for serial type.
   */
  serialType: string;
  /**
   * Value for serial number list.
   */
  serialNumberList: any;
  /**
   * Value for destination to.
   */
  destinationTo: string;
  /**
   * Value for seial arrary.
   */
  serialArray = [];
  /**
   * Value for receipt date.
   */
  receiptDate: any;
  /**
   * Value for loading controller.
   */
  loading = this.loadCtrl.create({
    content: 'Please wait...'
  });
  /**
   * Value for csvlines.
   */
  csvLines = [];

  destination:string;
  item:any;
  headerid:any;
  poNumber:any;
/**
   * Value for checked lines.
   */
  checkedLines = [];

  constructor(private transfer: FileTransfer, public file: File,public navCtrl: NavController,public loadCtrl: LoadingController, private datePipe: DatePipe, public alertCtrl: AlertController, public navParams: NavParams, public modalCtrl: ModalController, private dataprovider: DataProvider, private singleton: SingletonProvider, private globalvars: GlobalvariablesProvider, private databaseprovider: DatabaseProvider) {
    if (this.globalvars.getDemo() === "1" || this.globalvars.getDemo() === 1) {
      this.poSubItemDetails = this.navParams.get("data");
      this.poItemDetails = this.poSubItemDetails.ITEM_DETAILS;
      this.receivedBy = this.globalvars.getUserFullName();
      this.receivedQty = this.poSubItemDetails.QUAN_RECV;
      this.receiptDate = new Date().toISOString();
      this.getDemoSubInventory();
      this.getDemoLocators();
      this.getDemoLots();
      this.getDemoSerialNumbers();
    } else {
      this.poSubItemDetails = this.navParams.get("data");
      this.poNumber=this.navParams.get("data1");
      console.log(this.poSubItemDetails);
      this.poLineId = this.poSubItemDetails.PO_LINE_ID;
      this.poLineLocationId = this.poSubItemDetails.LINE_LOCATION_ID;
      this.receivedQty = this.poSubItemDetails.QUAN_RECV;
      this.receivedBy = this.globalvars.getUserFullName();
      // this.receiptDate = new Date().toISOString();
      this.receiptDate = this.datePipe.transform(new Date(), 'dd-MMM-yyyy');
      this.getItemDetails();
      this.getSubInventory();
      // this.destination=this.globalvars.getdestination();
      // console.log(this.destination);


      // this.getLotNumbers();
    }
    console.log("constructor");
  }

  /**
   * Method invoked when page is loaded.
   */
  ionViewDidLoad() {
    console.log('ionViewDidLoad PoitemdetailPage');
    console.log(this.poItemDetails);
  //   let item=this.globalvars.getItem();
  //   console.log(item);
  // if(this.destination === 'Inventory' && this.item==item) {
  //     console.log("inventory save details");
  //    this.subInventory =this.globalvars.getsubInventory();
  //    console.log(this.subInventory);
  //    this.locators = this.globalvars.getLocators();
  //    this.lotnumber= this.globalvars.getlotnumber();
  //    this.minserialnumber=this.globalvars.getMinserialnumber();
  //    this.maxserialnumber=this.globalvars.getMaxserialnumber();
  //    }

  }

  /**
   * Method loaded when page entered.
   */
  ionViewWillEnter() {
    if (this.globalvars.getDemo() === "1" || this.globalvars.getDemo() === 1) {
      this.destinationType = this.poItemDetails[0].DESTINATION_TYPE;
      this.override = this.poItemDetails[0].OVERRIDE_STATUS;
    }
    console.log(this.destinationType + "this is " + this.override);
  }


   getReceivingoverride(){
   this.destination="Receiving"
    console.log(this.destination + "vakue dnaskldsf");
    this.destinationTo = "Receiving";

   }


   getReceivingnooverride(){
     this.destination="Receiving";
    console.log(this.destination + "vakue dnaskldsf");
    this.destinationTo = "Receiving";
     }


   getinventorynooverride(){
    this.destination="Inventory";
    console.log(this.destination + "vakue dnaskldsf");
    this.destinationTo = "Inventory";
   }


  // Open model to show the data
  /**
   * Method to open custom model when clicked on icon.
   *
   * @param text text of particular model.
   */
  openModel(text) {
    console.log("this is model");
    /**
     * Selct moddel and open particular model.
     */
    let selectModal = this.modalCtrl.create(SelectmodalPage, { data: text, invitemid: this.inventoryItemId, subinventory: this.subInventory, lineid: this.poLineId });
    selectModal.present();
    selectModal.onDidDismiss(data => { //This is a listener which wil get the data passed from modal when the modal's view controller is dismissed
      console.log("Data =>", data) //This will log the form entered by user in add modal.
      if (text == 'Locators') {
        this.locators = data.LOCATOR_LIST;
      } else if (text == 'Lot Number') {
        this.lotnumber = data.LOT_NUMBER;
      } else if (text == 'minserialnumber') {
        this.minserialnumber = data.SERIAL_NUMBER;
        // for max serial number
        let array = this.minserialnumber.split(" ");
        let qty = this.poItemDetails[0].Quantity_Received.split("E");
        console.log(array);
        this.maxserialnumber = "ALS" + (parseInt(array[1]) + parseInt(qty[0])).toString();
        if (this.serialArray.indexOf(this.maxserialnumber) > -1) {
          console.log("this is the max serial number");
        } else {
          console.log("this is the not present serial number");
          let alert = this.alertCtrl.create({
            title: 'Please check the maximum serial or Quantity',
            buttons: [
              { text: "ok" }
            ]

          });
          alert.present();
          this.maxserialnumber = " ";
        }
      }

    });
  }

  //method to get the item details from the rest service.

  /**
   * Method to get the item details of pativular po
   */
  getItemDetails() {
    this.loading.present();
    try {
      // url for getting item details
      /**
       * Rest sevice for poitem details.
       */
      let poItemDetailUrl = this.singleton.poItemDetails;
      // body to pass to the service
      // let body = {
      //   "P_ORG_ID": this.globalvars.getOrgId(),
      //   "P_PO_HEADER_ID": this.globalvars.getPoHeaderId(),
      //   "P_PO_LINE_ID": this.poLineId,
      //   "P_LINE_LOCATION_ID": this.poLineLocationId
      // }

      /**
       * Request body for poitem details rest service.
       */
      let body = {
        "GOODS_PO_ITM_DTLS":
        {
          "@xmlns": "http://xmlns.oracle.com/apps/po/rest/GOODS_PO_ITM_DTLS/get_po_item_dtls_f/",
          "RESTHeader":
          {
            "xmlns": "http://xmlns.oracle.com/apps/po/rest/GOODS_PO_ITM_DTLS/header",
            "Responsibility": "SYSTEM_ADMINISTRATOR",
            "RespApplication": "SYSADMIN",
            "SecurityGroup": "STANDARD",
            "NLSLanguage": "AMERICAN"
          },
          "InputParameters":
          {
            "P_ORG_ID": this.globalvars.getOrgId(),
            "P_PO_HEADER_ID": this.globalvars.getPoHeaderId(),
            "P_PO_LINE_ID": this.poLineId,
            "P_LINE_LOCATION_ID": this.poLineLocationId
          }
        }
      }

      console.log(body);
      // this.loading.present();

      /**
       * Calling of poitem details rest service using dataprovider getgoodsdata method.
       */
      this.dataprovider.getGoodsData(poItemDetailUrl, body).subscribe(data => {
        console.log(data);
        // this.loading.dismiss();
        let dataString = data.OutputParameters.GET_PO_ITEM_DTLS_F;
        console.log(dataString);
        if (typeof dataString === 'object') {

        } else {
          let resultList = JSON.parse(dataString);
          console.log(resultList.data);
          this.poItemDetails = resultList.data;
          /**
           * To insert the item detials data into sqlite database.
           */
          this.databaseprovider.insertIntoPoItemDetails(resultList.data[0]).then(res => {
            console.log(res);
          }).catch(e => {
            console.log("error" + e.message);
          });
          this.destinationType = resultList.data[0].DESTINATION_TYPE;
          this.destination=this.destinationType;
          this.detailsLineLocationId = resultList.data[0].LINE_LOCATION_ID;
          this.override = resultList.data[0].OVERRIDE_STATUS;
          console.log(this.override);
          this.inventoryItemId = resultList.data[0].INVENTORY_ITEM_ID;
          this.defaultSubInventory = resultList.data[0].SUBINVENTORY;
          this.item=resultList.data[0].ITEM;
          let PO_HEADER_ID=resultList.data[0].PO_HEADER_ID;
          console.log(this.defaultSubInventory);
          console.log(this.override);
          console.log(this.destinationType);
        /* saved data */
          let item=this.globalvars.getItem();
          let savedHeaderId=this.globalvars.getPoHeaderId();
          let PO=this.globalvars.getponumber();
          console.log(savedHeaderId);
          console.log(PO_HEADER_ID);
          console.log(item);
          console.log(this.poNumber);
        let po=this.globalvars.getponumber();
        console.log(po);
        let llid=this.globalvars.getlinelocationid();
        console.log(llid);
        console.log(this.poLineLocationId);
 if(this.destinationType === 'Inventory' && this.item==item &&this.poLineLocationId==llid && po==this.poNumber ) {
           this.destination="Inventory";
            console.log("inventory save details");
           this.subInventory =this.globalvars.getsubInventory();
           console.log(this.subInventory);

           this.locators = this.globalvars.getLocators();
           this.lotnumber= this.globalvars.getlotnumber();
           this.minserialnumber=this.globalvars.getMinserialnumber();
           this.maxserialnumber=this.globalvars.getMaxserialnumber();
           }
  if(this.destinationType=='Receiving'&& this.item==item && this.poLineLocationId==llid && po==this.poNumber){
            this.destination="Receiving";
            console.log("receiving save details");
           }
   /* end */
          this.getLotNumbers();
          this.getSerialNumbers();
          this.loading.dismiss();
        }
      })

    } catch (e) {
      console.log("error");
    }

    // this.databaseprovider.getList("PO_ITEM_DETAILS").then(res => {
    //   console.log(res + "this is get sqlite");
    //   if (res.rows.length > 0) {
    //     console.log("this is offline");
    //     for (var i = 0; i < res.rows.length; i++) {
    //       // this.listdis.push({ponumber: res.rows.item(i).PO_NUMBER,releases: res.rows.item(i).ELEASES, poheaderid: res.rows.item(i).PO_HEADER_ID, potype: res.rows.item(i).PO_TYPE, vendorname: res.rows.item(i).VENDOR_NAME, vendorsite: res.rows.item(i).VENDOR_SITE, items: res.rows.item(i).ITEMS, contract: res.rows.item(i).CONTRACT, requestor: res.rows.item(i).REQUESTOR, headerprice: res.rows.item(i).PO_HDR_PRICE, currency: res.rows.item(i).CURRENCY_CODE, creationdate: res.rows.item(i).CREATION_DATE,lastdate: res.rows.item(i).LAST_UPDATE_DATE });
    //     this.poItemDetails.push(res.rows.item(i));
    //     }
    //     console.log(JSON.stringify(this.poItemDetails)+"this is listids");
    //     // this.initializeItems();
    //   }
    //   })

  }

  // getting the list of storage locations or sun inventory
  /**
   * Method to get the list of subinventories.
   */
  getSubInventory() {
    this.loading.present();
    try {
      /**
       * Rest service for subinventory.
       */
      let subInventoryUrl = this.singleton.storageLocations;

      // let body = {
      //   "P_ORGANIZATION_ID": this.globalvars.getInvOrgId()
      // }

      /**
       * Request body for subinventory rest service.
       */
      let body = {
        "INV_STRG_LOCATIONS":
        {
          "@xmlns": "http://xmlns.oracle.com/apps/ar/rest/INV_STRG_LOCATIONS/get_storage_location_f/",
          "RESTHeader":
          {
            "xmlns": "http://xmlns.oracle.com/apps/ar/rest/INV_STRG_LOCATIONS/get_cm_hdr_dtls_p/",
            "Responsibility": "SYSTEM_ADMINISTRATOR",
            "RespApplication": "SYSADMIN",
            "SecurityGroup": "STANDARD",
            "NLSLanguage": "AMERICAN",
            "Org_Id": "7911"
          },
          "InputParameters":
          {
            "P_ORGANIZATION_ID": this.globalvars.getInvOrgId()
          }
        }
      }

      /**
       * Calling of subinventory rest service using dataprovider getcommondata method.
       */
      this.dataprovider.getCommonData(subInventoryUrl, body).subscribe(data => {
        // console.log(data);
        let dataString = data.OutputParameters.GET_STORAGE_LOCATION_F;
        console.log(dataString);
        if (typeof dataString === 'object') {

        } else {
          let resultList = JSON.parse(dataString);
          // console.log(resultList.data);
          this.subinventoryList = resultList.data;
        }
      })
    this.loading.dismiss();
    } catch (e) {
      console.log("error");
    }
  }

  // After selecting the subinventory from the dropdown
  /**
   * Method to get the value of the selected subinventory.
   *
   * @param subInventoryValue Selected subinventory.
   */
  onChange(subInventoryValue) {
    console.log(subInventoryValue)
    this.subInventory = subInventoryValue;
    this.getLocators();
  }

  // to get the locators list
  /**
   * Method to get the locators list.
   */
  getLocators() {
    try {
      /**
       * Rest service for locators list.
       */
      let locatorsUrl = this.singleton.locators;

      // let body = {
      //   "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
      //   "P_SUBINVENTORY_CODE": this.subInventory,
      //   "P_PO_LINE_ID": this.poLineId
      // }

      /**
       * Request body for locators list rest service.
       */
      let body = {
        "INV_LOCATORS":
        {
          "@xmlns": "http://xmlns.oracle.com/apps/ar/rest/INV_LOCATORS/get_locator_f/",
          "RESTHeader":
          {
            "xmlns": "http://xmlns.oracle.com/apps/ar/rest/INV_LOCATORS/get_cm_hdr_dtls_p/",
            "Responsibility": "SYSTEM_ADMINISTRATOR",
            "RespApplication": "SYSADMIN",
            "SecurityGroup": "STANDARD",
            "NLSLanguage": "AMERICAN",
            "Org_Id": "7914"
          },
          "InputParameters":
          {
            "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
            "P_SUBINVENTORY_CODE": this.subInventory,
            "P_PO_LINE_ID": this.poLineId
          }
        }
      }
      console.log(body);
      /**
       * Calling of locators list rest service using dataprovider getcommondata method.
       */
      this.dataprovider.getCommonData(locatorsUrl, body).subscribe(data => {
        console.log(data);
        let dataString = data.OutputParameters.GET_LOCATOR_F;
        console.log(dataString);
        if (typeof dataString === 'object') {

        } else {
          let resultList = JSON.parse(dataString);
          console.log(resultList.data);
          console.log(this.subInventory);
          this.locatorsList = resultList.data;
          this.locatorType = resultList.data[0].LOCATOR_TYPE;
          console.log(this.locatorType);
        }
      })

    } catch (e) {
      console.log("error");
    }
  }

  //get the lotnumbers list

  /**
   * Method for getting the lotnumbers list.
   */
  getLotNumbers() {
    try {
      /**
       * Rest service for lotnumber.
       */
      let lotnumbersUrl = this.singleton.lotNumbers;

      // let body = {
      //   "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
      //   "P_INVENTORY_ITEM_ID": this.inventoryItemId,
      //   "P_PO_LINE_ID": this.poLineId
      // }

      /**
       * Request body for lotnumber rest service.
       */
      let body = {
        "INV_LOT_NUMBERS":
        {
          "@xmlns": "http://xmlns.oracle.com/apps/ar/rest/INV_LOT_NUMBERS/get_lot_number_f/",
          "RESTHeader":
          {
            "xmlns": "http://xmlns.oracle.com/apps/ar/rest/INV_LOT_NUMBERS/get_cm_hdr_dtls_p/",
            "Responsibility": "SYSTEM_ADMINISTRATOR",
            "RespApplication": "SYSADMIN",
            "SecurityGroup": "STANDARD",
            "NLSLanguage": "AMERICAN",
            "Org_Id": "7911"
          },
          "InputParameters":
          {
            "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
            "P_INVENTORY_ITEM_ID": this.inventoryItemId,
            "P_PO_LINE_ID": this.poLineId
          }
        }
      }
      console.log(body);
      /**
       * Calling of lotnumber rest service using dataprovider getcommondata method.
       */
      this.dataprovider.getCommonData(lotnumbersUrl, body).subscribe(data => {
        console.log(data);
        let dataString = data.OutputParameters.GET_LOT_NUMBER_F;
        console.log(dataString);
        if (typeof dataString === 'object') {

        } else {
          let resultList = JSON.parse(dataString);
          console.log(resultList.data);
          this.lotNumbersList = resultList.data;
          this.lotType = resultList.data[0].LOT_TYPE;
          this.lotGeneration = resultList.data[0].LOT_GENERATION;
        }
      })

    } catch (e) {
      console.log("error");
    }
  }

  // get serial numbers list
  /**
   * Method to get serial numbers list.
   */
  getSerialNumbers() {
    try {
      /**
       * Rest service for serial number list.
       */
      let serialNumbersUrl = this.singleton.serialNumbers;

      // let body = {
      //   "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
      //   "P_INVENTORY_ITEM_ID": this.inventoryItemId,
      //   "P_PO_LINE_ID": this.poLineId
      // }

      /**
       * Request body for serial number rest service.
       */
      let body = {
        "INV_SERIAL_NUMBERS":
        {
          "@xmlns": "http://xmlns.oracle.com/apps/po/rest/INV_SERIAL_NUMBERS/get_serial_f/",
          "RESTHeader":
          {
            "xmlns": "http://xmlns.oracle.com/apps/po/rest/INV_SERIAL_NUMBERS/header",
            "Responsibility": "SYSTEM_ADMINISTRATOR",
            "RespApplication": "SYSADMIN",
            "SecurityGroup": "STANDARD",
            "NLSLanguage": "AMERICAN"
          },
          "InputParameters":
          {
            "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
            "P_INVENTORY_ITEM_ID": this.inventoryItemId,
            "P_PO_LINE_ID": this.poLineId
          }
        }
      }

      /**
       * Calling of serial number rest servie using dataprovider getcommondata method.
       */
      this.dataprovider.getCommonData(serialNumbersUrl, body).subscribe(data => {
        console.log(data);
        let dataString = data.OutputParameters.GET_SERIAL_F;
        console.log(dataString);
        if (typeof dataString === 'object') {

        } else {
          let resultList = JSON.parse(dataString);
          console.log(resultList.data);
          this.serialNumberList = resultList.data;
          for (let i = 0; i < this.serialNumberList.length; i++) {
            this.serialArray.push(this.serialNumberList[i].SERIAL_NUMBER);

          }
          console.log(this.serialArray + "this is array");
          this.serialType = resultList.data[0].SERIAL_TYPE;
          if (this.serialType === 'Dynamic Entry') {
            // this.maxserialnumber=parseInt(this.minserialnumber)+parseInt(resultList.data[0].Quantity_Received);
            console.log(this.minserialnumber + "min serial number");
            this.maxserialnumber = this.minserialnumber;
            console.log(this.maxserialnumber + "max serial number");
          }
        }
      })

    } catch (e) {
      console.log("error");
    }
  }

  /**
   * Method to save some data to the sqlite database.
   */
  saveData() {
    // this.navCtrl.push(PoitemsPage);
    /**
     * Chaging the locator value.
     */
    if (this.locatorType == 'NO LOCATOR') {
      this.locators = " "
    } else {
      this.locators = this.locators + ".."
    }
    try {
      if (this.globalvars.getDemo() === "1" || this.globalvars.getDemo() === 1) {
        // this.navCtrl.pop();
      } else {
        /**
         * Set teh data to receiptedetails object.
         */
        this.receiptDetails.linelocation = this.detailsLineLocationId;
        this.receiptDetails.destination = this.destinationTo;
        this.receiptDetails.overridestatus = this.override;
        this.receiptDetails.subinventory = this.subInventory;
        this.receiptDetails.locator = this.locators;
        this.receiptDetails.lot = this.lotnumber;
        this.receiptDetails.min_serial = this.minserialnumber;
        this.receiptDetails.max_serial = this.maxserialnumber;
        this.receiptDetails.quantityrec = this.receivedQty;
        this.receiptDetails.receiptdate = this.datePipe.transform(new Date(), 'dd-MMM-yyyy');
        this.receiptDetails.userid = this.globalvars.getUserId();
        console.log(this.destination);

        // LINE_LOCATION_ID',
        // 'PO_HEADER_ID',
        // 'RELESENUM',

        // 'QUNATITY_RECV',
        // 'DESTINATION', '
        // ORG_ID',
        // 'SUBINVENTORY',
        // 'LOCATOR',
        //  'LOT',
        //  'MAX_SERIAL',
        //  'MIN_SERIAL',
        //  'RECEIPT_DATE',
        //   'USERID
       if(this.destinationType=="Inventory" ){
         console.log("set inventory")
        //  LINE_LOCATION_ID
        this.globalvars.setlinelocationid(this.poLineLocationId);
        this.globalvars.setdestination(this.destination);
        this.globalvars.setsubInventory(this.subInventory);
        this.globalvars.setponumber(this.poNumber);
        this.globalvars.setLocators(this.locators);
        this.globalvars.setlotnumber(this.lotnumber);
        this.globalvars.setMinserialnumber(this.minserialnumber);
        this.globalvars.setMaxserialnumber(this.maxserialnumber);
        this.globalvars.setItem(this.poItemDetails[0].ITEM);
        this.globalvars.setPoHeaderId(this.poItemDetails[0].PO_HEADER_ID);
       }
       if(this.destinationType=="Receiving"){
         console.log("receiving");
        this.globalvars.setlinelocationid(this.poLineLocationId);
        this.globalvars.setponumber(this.poNumber);
         this.globalvars.setdestination(this.destination);
         this.globalvars.setItem(this.poItemDetails[0].ITEM);
        this.globalvars.setPoHeaderId(this.poItemDetails[0].PO_HEADER_ID);
       }
        /**
         * Adding the receipt details to Sqlite database.
         */
        this.databaseprovider.insertIntoReceiptDetails(this.receiptDetails).then(res => {
          console.log(res);
          if (res) {
            // this.navCtrl.pop();
          }
        }).catch(e => {
          console.log("error message" + e.code);
          /**
           * If the error code is 6 then update the values in Sqlite database.
           */
          if (e.code == "6" || e.code == 6) {
            let alert = this.alertCtrl.create({
              subTitle: 'Receipt Details already stored do you want to update?',
              buttons: [{
                text: 'OK',
                handler: () => {
                  this.updateDetails(this.receiptDetails);
                }
              }, {
                text: 'Cancel',
                role: 'cancel',
                handler: data => {
                  console.log('Cancel clicked');
                }
              }]
            });
            alert.present();
          }
        })
      }

    } catch (error) {
      console.log("error " + error.message);

    }
  }

  /**
   * Method to update the values of particular table.
   *
   * @param details Details that to be updated.
   */
  updateDetails(details) {
    this.databaseprovider.updateTable(this.receiptDetails).then(res => {
      console.log(res + "row updated");
      if(res){
        // this.navCtrl.pop();
      }
    }).catch(e => {
      console.log("error while updating" + e.message);
    });

  }


  // to get the destination  type either receiving or Inventory
  /**
   * Method to get the destination value.
   *
   * @param destination Check box value.
   */
  getReceiving(destination) {
    console.log(destination + "vakue dnaskldsf");
    this.destinationTo = destination;
  }
  getReceivingnew(destination) {
    console.log(destination + "vakue dnaskldsf");
    this.destinationTo = destination;
  }
  // for demo mode subinventory
  /**
   * Method to get the subinventory data for demo mode.
   */
  getDemoSubInventory() {
    this.dataprovider.getSubInventoryJsonData().subscribe(data => {
      console.log(data);
      this.subinventoryList = data.SUBIVENTORY_LIST;
    });
  }

  // for demo locators
  /**
   * Method to get the locators data for demo mode.
   */
  getDemoLocators() {
    this.dataprovider.getSubInventoryJsonData().subscribe(data => {
      console.log(data);
      this.locatorsList = data.LOCATORS;
      this.locatorType = this.locatorsList[0].LOCATOR_TYPE;
    });
  }

  // for demo lots
  /**
   * Method to get the lotnumber data for demo mode.
   */
  getDemoLots() {
    this.dataprovider.getSubInventoryJsonData().subscribe(data => {
      console.log(data);
      this.lotNumbersList = data.LOT;
      this.lotType = this.lotNumbersList[0].LOT_TYPE;
      this.lotGeneration = this.lotNumbersList[0].LOT_GENERATION;
    });
  }

  // for demo lots
  /**
   * Method to get the serial number data for demo mode.
   */
  getDemoSerialNumbers() {
    this.dataprovider.getSubInventoryJsonData().subscribe(data => {
      console.log(data);
      this.serialNumberList = data.SERIAL;
      this.serialType = this.serialNumberList[0].SERIAL_TYPE;
    });
  }
/**
   * Method to perform the receipt.
   */
  Receipt() {
    // this.navCtrl.push(ReceiptsPage);
    if (this.globalvars.getDemo() === "1" || this.globalvars.getDemo() === 1) {
      this.loading.present();
      setTimeout(() => {
        this.loading.dismiss();
        this.showAlert();
      }, 5000);
    } else {
      this.loading.present();

      this.checkedLines.push(this.poSubItemDetails);
       /**
     * Get the data of the checked items from the Sqlite database.
     */
    console.log(this.poSubItemDetails);
    // this.databaseprovider.getReceiptElements(this.poSubItemDetails).then((res) => {

    //   console.log(res + "this is res of the joimns");
      // this.csvLines = res;
      // let receptLines=[];
      // console.log(res.rows.length + "this is the length of outpiut");
      // if (res.rows.length > 0) {
        // for (var i = 0; i < res.rows.length; i++) {
          // this.csvLines.push({PO_LINE_LOCATION_ID:res.rows.item(i).LINE_LOCATION_ID,PO_HEADER_ID:res.rows.item(i).PO_HEADER_ID,PO_RELESE_NUM:res.rows.item(i).RELESENUM,QUANTITY_RECEIVED:res.rows.item(i).QUNATITY_RECV,DESTINATION_TYPE:res.rows.item(i).DESTINATION,INV_ORG_ID:res.rows.item(i).ORG_ID,SUB_INVENTORY:res.rows.item(i).SUBINVENTORY,LOCATOR:res.rows.item(i).LOCATOR,LOT:res.rows.item(i).LOT,MAX_SERIAL:res.rows.item(i).MAX_SERIAL,MIN_SERIAL:res.rows.item(i).MIN_SERIAL,DELIVERY_DATE:res.rows.item(i).DELIVERY_DATE,USER_ID:res.rows.item(i).USERID})
          // this.csvLines.push(res.rows.item(i));
      // }
      // }
      // console.log(this.csvLines + "this is some values in table");
      // if (this.csvLines.length > 0) {
        // this.createCSV(this.csvLines);
        // console.log(this.csvLines + "array of output");
      // } else {
        // console.log("Not created");
        // this.loading.dismiss();
        // let alert = this.alertCtrl.create({
          // subTitle: 'Please save data and perform receipt',
          // buttons: [{
            // text: 'OK',
            // handler: () => {
            //   this.navCtrl.setRoot(PolistPage);
            // }
          // }]
        // });
        // alert.present();
      // }
    // }, (err) => {
      // console.log(err.message + "joins error");
    // });


      if (this.checkedLines.length > 0) {
        this.retrieveData(this.checkedLines);

      }
      else {
         this.loading.dismiss() /* loading error   venu  */
        let alert = this.alertCtrl.create({
          subTitle: 'No Line item',
          buttons: [{
            text: 'OK'
          }]
        });
        alert.present();
        }
    }

    this.globalvars.setsubInventory("");
    this.globalvars.setponumber("");
    this.globalvars.setLocators("");
    this.globalvars.setlotnumber('');
    this.globalvars.setMinserialnumber('');
    this.globalvars.setMaxserialnumber('');

  }

 /**
   * Method to perform the receipt by convertint the data to CSV format.
   *
   * @param checkeditems checked items
   */
  retrieveData(checkeditems) {
    console.log(checkeditems);
    /**
     * Get the data of the checked items from the Sqlite database.
     */
    this.databaseprovider.getReceiptElements(checkeditems).then((res) => {

      console.log(res + "this is res of the joimns");
      // this.csvLines = res;
      // let receptLines=[];
      console.log(res.rows.length + "this is the length of outpiut");
      if (res.rows.length > 0) {
        for (var i = 0; i < res.rows.length; i++) {
          // this.csvLines.push({PO_LINE_LOCATION_ID:res.rows.item(i).LINE_LOCATION_ID,PO_HEADER_ID:res.rows.item(i).PO_HEADER_ID,PO_RELESE_NUM:res.rows.item(i).RELESENUM,QUANTITY_RECEIVED:res.rows.item(i).QUNATITY_RECV,DESTINATION_TYPE:res.rows.item(i).DESTINATION,INV_ORG_ID:res.rows.item(i).ORG_ID,SUB_INVENTORY:res.rows.item(i).SUBINVENTORY,LOCATOR:res.rows.item(i).LOCATOR,LOT:res.rows.item(i).LOT,MAX_SERIAL:res.rows.item(i).MAX_SERIAL,MIN_SERIAL:res.rows.item(i).MIN_SERIAL,DELIVERY_DATE:res.rows.item(i).DELIVERY_DATE,USER_ID:res.rows.item(i).USERID})
          this.csvLines.push(res.rows.item(i));
      }
      }
      console.log(this.csvLines + "this is some values in table");
      if (this.csvLines.length > 0) {
        this.createCSV(this.csvLines);
        console.log(this.csvLines + "array of output");
      } else {
        console.log("Not created");
        this.loading.dismiss();
        let alert = this.alertCtrl.create({
          subTitle: 'Please save the data and perform receipt',
          buttons: [{
            text: 'OK',
            // handler: () => {
            //   this.navCtrl.setRoot(PolistPage);
            // }
          }]
        });
        alert.present();
      }
    }, (err) => {
      console.log(err.message + "joins error");
    });
  }


  /**
   * Method to convert the list of data into CSv format using json to csv package.
   *
   * @param list rows of the checked items from database.
   */
  createCSV(list) {
    var json2csv = require('json2csv');
    // var fs = require('fs');
    var fields = ['LINE_LOCATION_ID', 'PO_HEADER_ID', 'RELESENUM', 'QUNATITY_RECV', 'DESTINATION', 'ORG_ID', 'SUBINVENTORY', 'LOCATOR', 'LOT', 'MAX_SERIAL', 'MIN_SERIAL', 'RECEIPT_DATE', 'USERID'];
    var myLines = list;
    var opts = {
      data: myLines,
      fields: fields,
      fieldNames: fields,
      quotes: '',
      newLine: ";"
    };
    var csv = json2csv(opts);
    console.log(csv + "this is csv" + typeof csv);
    /**
     * REst api for creating the receipt.
     */
    let interfaceUrl = this.singleton.interfacecsv;
    /**
     * Request body for interface rest service.
     */
    let body = {
      "parse_csv":
      {
        "@xmlns": "http://vis1225.dpebs-server.com:8000/webservices/rest/parse_csv/get_parse_json_p",
        "RESTHeader":
        {
          "xmlns": "http://vis1225.dpebs-server.com:8000/webservices/rest/parse_csv/header",
          "Responsibility": "SYSTEM_ADMINISTRATOR",
          "RespApplication": "SYSADMIN",
          "SecurityGroup": "STANDARD",
          "NLSLanguage": "AMERICAN",
          "Org_Id": "7914"
        },
        "InputParameters":
        {
          "P_CSV_DATA": csv
        }
      }
    }



    /**
     * Calling of the interface rest service using dataprovider getgoodsdata method.
     */
    this.dataprovider.getGoodsData(interfaceUrl, body).subscribe(receiptdata => {

      console.log(receiptdata);
      this.loading.dismiss();
      let dataString = receiptdata.OutputParameters.V_RECEIPT_NUMBER_OUT;
      let message = receiptdata.OutputParameters.V_RECEIPT_MESSAGE_OUT;
      console.log(dataString);
      /**
       * If there is no data received from the service.
       */
      if (typeof dataString === 'object') {
        let alert = this.alertCtrl.create({
          subTitle: 'Receipt is not generated. Please check the data',
          buttons: [{
            text: 'OK',
            // handler: () => {
            //   this.navCtrl.setRoot(PolistPage);
            // }
          }]
        });
        alert.present();
      } else {
        let resultList = dataString;
        let resultmessage = message;
        console.log(resultList + "this is receipt number");
        /**
         * If the result message is success.
         */
        if (resultmessage == "SUCCESS") {
          this.receiptAlert(resultList);
          csv="";
          /**
           * Delete the selected rows data after the receipt is performed.
           */
          this.databaseprovider.deleteList("PURCHASEORDER_ITEMS", this.poSubItemDetails).then((res) => {
                console.log("this row is line deleted" + res);
                if(res.rows.length > 0){
                  this.databaseprovider.deleteList("PO_ITEM_DETAILS",this.poSubItemDetails).then((result) => {
                    console.log("this rows deleted from poitem details"+ result);
                    if(result.rows.length > 0){
                      this.databaseprovider.deleteList("RECEIPT_ITEM_DETAILS",this.poSubItemDetails).then((response) => {
                        console.log("this row deleted from receipt details"+ response);
                      }),(err => {
                        console.log("error for deleting receipt details" + err);
                      })
                    }
                  }),(err => {
                    console.log("error for deleting poitem details" + err);
                  })
                }
              }), (err => {
                console.log("error for line deleting" + err);
              })
        }else{
          this.receiptError(resultList);
        }
      }
    });

    console.log(this.file.dataDirectory + "data directory");
    this.file.writeFile(this.file.externalDataDirectory, 'sample.csv', csv).then(res => {
      if (res) {
        console.log(res);
        // this.uploadFile();
      }
    });
  }


  /**
   * Method to upload a file.
   */
  uploadFile() {
    const fileTransfer: FileTransferObject = this.transfer.create();
    //   let options: FileUploadOptions = {
    //     fileKey: 'sample',
    //     fileName: 'sample.csv',
    //  }
    let fileurl = encodeURI('/opt/ebs/oracle/VIS/12.1.0/appsutil/outbound/VIS_ebsol');
    console.log(this.file.externalDataDirectory + 'sample.csv');
    fileTransfer.upload(this.file.externalDataDirectory + 'sample.csv', fileurl)
      .then((data) => {
        // success
        console.log(data);
      }, (err) => {
        // error
        console.log(err.code + "this is error");
      })
  }

  /**
   * Method to show alert after the success of the receipt generation.
   *
   * @param receiptNum Receipt number received from rest service after success.
   */
  receiptAlert(receiptNum) {
    let alert = this.alertCtrl.create({
      // subTitle: 'Receipt is generated with Receipt Number:' + receiptNum,
      subTitle: 'Received successfully with the receipt number :' + receiptNum,
      buttons: [{
        text: 'OK',
        handler: () => {
          this.navCtrl.setRoot(PolistPage);
        }
      }]
    });
    alert.present();

  }

  /**
   * Method to show alert with the error message.
   *
   * @param receiptError Error message from the service.
   */
  receiptError(receiptError){
    let alert = this.alertCtrl.create({
      subTitle: 'Error Message:' + receiptError,
      buttons: [{
        text: 'OK',
        handler: () => {
          this.navCtrl.setRoot(PolistPage);
        }
      }]
    });
    alert.present();
  }

  /**
   * Method to show alert for demo mode.
   */
  showAlert() {
    let alert = this.alertCtrl.create({
      subTitle: 'Receipt is generated with Receipt Number: 9',
      enableBackdropDismiss:false,
      buttons: [{
        text: 'OK',
        handler: () => {
          this.navCtrl.setRoot(PolistPage);
        }
      }]
    });
    alert.present();
  }


}

import { DatabaseProvider } from './../../providers/database/database';
import { SingletonProvider } from '../../providers/singleton/singleton';
import { DataProvider } from './../../providers/data/data';
import { GlobalvariablesProvider } from './../../providers/globalvariables/globalvariables';
import { PosettingsPage } from './../posettings/posettings';
import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController ,MenuController} from 'ionic-angular';
import { PoitemsPage } from './../poitems/poitems';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';
import { Keyboard } from '@ionic-native/keyboard';

/**
 * Generated class for the PolistPage page.
 *
 * PolistPage class to get the purchase orders list from the service.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-polist',
  templateUrl: 'polist.html',
})
export class PolistPage {
  /**
   * Value for polist.
   */
  poList=[];
  /**
   * Value for items.
   */
  items: any;
  /**
   * Value for output.
   */
  output: any;
  /**
   * Value for input search.
   */
  myInput: any;
  /**
   * Value for listids.
   */
  listdis = [];
  /**
   * Value for loading controller.
   */
  loading = this.loadCtrl.create({
    content: 'Please wait...'
  });
  constructor(public navCtrl: NavController,private keyboard: Keyboard,public menuCtrl: MenuController, public loadCtrl: LoadingController, public navParams: NavParams, private globalvars: GlobalvariablesProvider, private dataprovider: DataProvider, private singleton: SingletonProvider, private databaseprovider: DatabaseProvider, private barcode: BarcodeScanner) {
    console.log(this.globalvars.getDemo());
    /**
     * Check whether the app is running in demo mode or normal mode.
     */
    if (this.globalvars.getDemo() === "1" || this.globalvars.getDemo() === 1) {
      this.getDemoPoList();
    } else {
      this.getPoList();
      // this.setPolist();
    }
  }

  /**
   * Method invoked when we entered the page.
   */
  ionViewWillEnter() {

    // this.getSqlitepolist();
    //  this.sample.createdb();
  }

  /**
   * Method invoked when page is loaded.
   */
  ionViewDidLoad() {
    console.log('ionViewDidLoad PolistPage');
    // this.getSqlitepolist();

  }

  /**
   * Method to toggle sidemenu.
   */
  sideMenu() {
    this.menuCtrl.toggle();
  }

  /**
   * Method to go to settings page.
   */
  goToSettings() {
    this.navCtrl.push(PosettingsPage);
  }
  //moving to Poitemspage and sending the data to next page
  /**
   * Method to go to next page with the item.
   *
   * @param item Item fromlist page.
   */
  goToPoReceipt(item) {
    this.navCtrl.push(PoitemsPage, { data: item });
   let po=this.globalvars.getponumber();
   console.log(po);
   console.log(item.PO_NUMBER);
    if(item.PO_NUMBER !=po) {
    this.globalvars.setsubInventory("");

   this.globalvars.setLocators("");
   this.globalvars.setlotnumber('');
   this.globalvars.setMinserialnumber('');
   this.globalvars.setMaxserialnumber('');
    }
  }
  // to get the polist from the backend
  /**
   * Method to get the purchase orders list from the service.
   */
  getPoList() {
    /**
     * Check whether the app is running in demo mode or normal mode.
     */
    try {
      if (this.globalvars.getOrgId() === " " || this.globalvars.getInvOrgId() === "" || this.globalvars.getDeliveryDate() === "" || this.globalvars.getOrgId() === undefined || this.globalvars.getInvOrgId() === undefined) {
        this.getPolistDefault();
      } else {
        this.getPolistDateSelected();
      }

    } catch (e) {
      console.log("error");
    }

  }

  /**
   * Method to get the po list by having default input parameters.
   */
  getPolistDefault() {
    try {
      /**
       * Rest service for polist.
       */
      let polistUrl = this.singleton.poList;
      /**
       * Request body for polist rest service.
       */
      let body = {
        "GDS_RCPTS_PO_LIST":
        {
          "@xmlns": "http://xmlns.oracle.com/apps/po/rest/GDS_RCPTS_PO_LIST/get_po_list_f/",
          "RESTHeader":
          {
            "xmlns": "http://xmlns.oracle.com/apps/po/rest/GDS_RCPTS_PO_LIST/header",
            "Responsibility": "SYSTEM_ADMINISTRATOR",
            "RespApplication": "SYSADMIN",
            "SecurityGroup": "STANDARD",
            "NLSLanguage": "AMERICAN",
            "Org_Id": "7911"
          },
          "InputParameters":
          {
            "P_ORG_ID": "7911",
            "P_ORGANIZATION_ID": "7914"
          }
        }
      }


      // calling the api through dataprovider
      this.loading.present();

      /**
       * Calling of polist rest service with default input parameters using dataprovider getgoodsdata method.
       */
      this.dataprovider.getGoodsData(polistUrl, body).subscribe(data => {
        console.log(data);
        this.loading.dismiss();
        let dataString = data.OutputParameters.GET_PO_LIST_F;
        console.log(dataString);
        if (typeof dataString === 'object') {

        } else {
          let resultList = JSON.parse(dataString);
          console.log(resultList.data);
          this.poList = resultList.data;
          //  this.poList.sort()
          /**
           * Insert polist data into Sqlite database.
           */
          this.databaseprovider.insertIntoPoList(this.poList).then(res => {
            console.log(res);
          });
          this.initializeItems();
          console.log(this.poList);

          // this.setPolist();
        }
      });

      this.globalvars.setOrgId("7911");
      this.globalvars.setInvOrgId("7914");

    } catch (e) {
      console.log("error" + e);
    }

    // this.databaseprovider.getList("PURCHASEORDER_LIST").then(res => {
    //   console.log(res + "this is get sqlite");
    //   if (res.rows.length > 0) {
    //     console.log("this is offline");
    //     for (var i = 0; i < res.rows.length; i++) {
    //       // this.listdis.push({ponumber: res.rows.item(i).PO_NUMBER,releases: res.rows.item(i).ELEASES, poheaderid: res.rows.item(i).PO_HEADER_ID, potype: res.rows.item(i).PO_TYPE, vendorname: res.rows.item(i).VENDOR_NAME, vendorsite: res.rows.item(i).VENDOR_SITE, items: res.rows.item(i).ITEMS, contract: res.rows.item(i).CONTRACT, requestor: res.rows.item(i).REQUESTOR, headerprice: res.rows.item(i).PO_HDR_PRICE, currency: res.rows.item(i).CURRENCY_CODE, creationdate: res.rows.item(i).CREATION_DATE,lastdate: res.rows.item(i).LAST_UPDATE_DATE });
    //       this.poList.push(res.rows.item(i));
    //     }
    //     console.log(JSON.stringify(this.poList)+"this is listids");
    //     this.initializeItems();
    //   }
    //   })

  }

  /**
   * Method to get polist with selected input parameters from settings page.
   */
  getPolistDateSelected() {
    try {
      /**
       * Rest service for polist.
       */
      let polistUrl = this.singleton.poList;
      let body = {
        "GDS_RCPTS_PO_LIST":
        {
          "@xmlns": "http://xmlns.oracle.com/apps/po/rest/GDS_RCPTS_PO_LIST/get_po_list_f/",
          "RESTHeader":
          {
            "xmlns": "http://xmlns.oracle.com/apps/po/rest/GDS_RCPTS_PO_LIST/header",
            "Responsibility": "SYSTEM_ADMINISTRATOR",
            "RespApplication": "SYSADMIN",
            "SecurityGroup": "STANDARD",
            "NLSLanguage": "AMERICAN",
            "Org_Id": "7911"
          },
          "InputParameters":
          {
            "P_ORG_ID": this.globalvars.getOrgId(),
            "P_ORGANIZATION_ID": this.globalvars.getInvOrgId()
          }
        }
      }

      // calling the api through dataprovider

      /**
       * Calling of polist rest service using dataprovider get data method.
       */
      this.dataprovider.getGoodsData(polistUrl, body).subscribe(data => {
        console.log(data);
        let dataString = data.OutputParameters.GET_PO_LIST_F;
        console.log(dataString);
        if (typeof dataString === 'object') {

        } else {
          let resultList = JSON.parse(dataString);
          console.log(resultList.data);
          this.poList = resultList.data;
          this.databaseprovider.insertIntoPoList(this.poList).then(res => {
            console.log(res);
          });
          this.initializeItems();
          // this.items=poList;
          console.log(this.poList);

          // this.setPolist();
        }
      });


    } catch (e) {
      console.log("error" + e);
    }

    //  this.databaseprovider.getList("PURCHASEORDER_LIST").then(res => {
    //     console.log(res + "this is get sqlite");
    //     if (res.rows.length > 0) {
    //       console.log("this is offline");
    //       for (var i = 0; i < res.rows.length; i++) {
    //         // this.listdis.push({ponumber: res.rows.item(i).PO_NUMBER,releases: res.rows.item(i).ELEASES, poheaderid: res.rows.item(i).PO_HEADER_ID, potype: res.rows.item(i).PO_TYPE, vendorname: res.rows.item(i).VENDOR_NAME, vendorsite: res.rows.item(i).VENDOR_SITE, items: res.rows.item(i).ITEMS, contract: res.rows.item(i).CONTRACT, requestor: res.rows.item(i).REQUESTOR, headerprice: res.rows.item(i).PO_HDR_PRICE, currency: res.rows.item(i).CURRENCY_CODE, creationdate: res.rows.item(i).CREATION_DATE,lastdate: res.rows.item(i).LAST_UPDATE_DATE });
    //         this.poList.push(res.rows.item(i));
    //       }
    //       console.log(JSON.stringify(this.poList)+"this is listids");
    //       this.initializeItems();
    //     }
    //     })

  }

   clearsearch() {
  //  this.initializeItems();
  this.getPoList();
  // console.log(this.poList);
   this.items=this.poList;
  //  console.log(this.items);
  //  this.doRefresh();
  //  this.doRefresh($event);
   console.log("ion clear");
   this.keyboard.close();
      }

  clearcancel(){
//  this.initializeItems();
 this.items=this.poList;
   console.log("ion cancel");
   this.keyboard.close();
 }

  /**
   * Method to initialize polist to items for searching.
   */
  initializeItems() {
    this.items = this.poList;
    console.log(this.poList.sort());

  }

  //for searching the purchase order according to the po number
  /**
   * Method to get the selected searched item.
   *
   * @param ev Event for searching the list.
   */
  getItems(ev: any) {
    console.log(this.myInput + "the output we are getting");
    // Reset items back to all of the items
    this.initializeItems();

    // set val to the value of the searchbar
    let val = ev.target.value;
    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {
      console.log(this.poList);
      console.log(val);
      this.items = this.items.filter((item) => {
        return (item.PO_NUMBER.toLowerCase().indexOf(val.toLowerCase()) > -1) || (item.PO_TYPE.toLowerCase().indexOf(val.toLowerCase()) > -1) || (item.VENDOR_NAME.toLowerCase().indexOf(val.toLowerCase()) > -1) || (item.CREATION_DATE.toLowerCase().indexOf(val.toLowerCase()) > -1) || (item.VENDOR_SITE.toLowerCase().indexOf(val.toLowerCase()) > -1) || (item.REQUESTOR.toLowerCase().indexOf(val.toLowerCase()) > -1);

      })
    }

  }

  // to scan the barcode
  /**
   * Method to scan the barcode and get the po details.
   */
  openBarcode() {

    this.barcode.scan().then((barcodeData) => {
      // Success! Barcode data is here
      console.log(barcodeData);
      this.output = barcodeData.text;
      this.myInput = this.output;
      console.log(typeof this.output);
      if (this.globalvars.getDemo() === "1" || this.globalvars.getDemo() === 1) {
        // this.getDemoBarcode(this.myInput);
      } else {
        this.getTheBarcodeDetails(this.myInput);
      }
    });
  }

  // setPolist() {
  //   this.databaseprovider.insertIntoPoList(this.list).then(res => {
  //     console.log(res);
  //   });
  // }

  // getting data from sqlite database

  /**
   * Method to get the data from the Sqlite database.
   */
  getSqlitepolist() {
    this.databaseprovider.getList("PURCHASEORDER_LIST").then(res => {
      console.log(res + "this is get sqlite");
      if (res.rows.length > 0) {
        for (var i = 0; i < res.rows.length; i++) {
          // this.listdis.push({ponumber: res.rows.item(i).PO_NUMBER,releases: res.rows.item(i).ELEASES, poheaderid: res.rows.item(i).PO_HEADER_ID, potype: res.rows.item(i).PO_TYPE, vendorname: res.rows.item(i).VENDOR_NAME, vendorsite: res.rows.item(i).VENDOR_SITE, items: res.rows.item(i).ITEMS, contract: res.rows.item(i).CONTRACT, requestor: res.rows.item(i).REQUESTOR, headerprice: res.rows.item(i).PO_HDR_PRICE, currency: res.rows.item(i).CURRENCY_CODE, creationdate: res.rows.item(i).CREATION_DATE,lastdate: res.rows.item(i).LAST_UPDATE_DATE });
          this.listdis.push(res.rows.item(i));
        }
      }
      console.log(this.listdis + "these are stored list");
    });
  }

  // when we refresh the page

  /**
   * Method to refresh the list to get new data.
   *
   * @param refresher refresh the list.
   */
  doRefresh(refresher) {
    console.log('Begin async operation', refresher);
    if (this.globalvars.getDemo() === "1" || this.globalvars.getDemo() === 1) {
      setTimeout(() => {
        console.log('Async operation has ended');
        refresher.complete();
      }, 2000);
    } else {
      setTimeout(() => {
        console.log('Async operation has ended');
        this.getPoList();
        refresher.complete();
      }, 2000);
    }
  }

  // get the scanned po using barcode

  /**
   * Method to get the barcode details from the service with some data.
   *
   * @param value Value form barcode scanning.
   */
  getTheBarcodeDetails(value) {
    /**
     * Rest service for barcode scanning.
     */
    let barcodeUrl = this.singleton.barcodeHdr;
    // let body = {
    //   "P_ORG_ID": this.globalvars.getOrgId(),
    //   "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
    //   "P_PO_NUMBER": value
    // }

    /**
     * Request body for barcode scanning rest service.
     */
    let body =
      {
        "GDS_BARCDE_HDR":
        {
          "@xmlns": "http://xmlns.oracle.com/apps/po/rest/GDS_BARCDE_HDR/get_barcode_header_f/",
          "RESTHeader":
          {
            "xmlns": "http://xmlns.oracle.com/apps/po/rest/GDS_BARCDE_HDR/header",
            "Responsibility": "SYSTEM_ADMINISTRATOR",
            "RespApplication": "SYSADMIN",
            "SecurityGroup": "STANDARD",
            "NLSLanguage": "AMERICAN",
            "Org_Id": "7911"
          },
          "InputParameters":
          {
            "P_ORG_ID": this.globalvars.getOrgId(),
            "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
            "P_PO_NUMBER": value
          }
        }
      }

    console.log(body);
    /**
     * Calling of rest service using dataprovider getgoodsdata method.
     */
    this.dataprovider.getGoodsData(barcodeUrl, body).subscribe(data => {
      console.log(data);
      let dataString = data.OutputParameters.GET_BARCODE_HEADER_F;
      console.log(dataString);
      if (typeof dataString === 'object') {
      //  this.poList=[];
       let polistb=[]
       this.items=polistb;
      //  this.initializeItems();
      } else {
        let resultList = JSON.parse(dataString);
        console.log(resultList.data);
        let poListb = resultList.data;
        // this.initializeItems();
        this.items=poListb;
        console.log(poListb);
      }

    });
  }

  // to get the purchase orders list from the local json file

  /**
   * Method to get the data from local file for demo mode.
   */
  getDemoPoList() {
    this.dataprovider.getJsonData().subscribe(data => {
      console.log(data);
      this.poList = data;
      this.initializeItems();
    });
  }

  // getDemoBarcode(barcodevalue) {

  // }

}

import { DataProvider } from './../../providers/data/data';
import { GlobalvariablesProvider } from './../../providers/globalvariables/globalvariables';
import { SingletonProvider } from './../../providers/singleton/singleton';
import { Component } from '@angular/core';
import { NavController, NavParams, ViewController } from 'ionic-angular';

/**
 * Generated class for the SelectmodalPage page.
 * 
 * SelectmodalPage class to open the custom modal for selecting locators,lots etc.,
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-selectmodal',
  templateUrl: 'selectmodal.html',
})
export class SelectmodalPage {
  /**
   * Value for modal text.
   */
  modalText: any;
  /**
   * Value for selected item.
   */
  selectedItem: any;
  /**
   * Value for items.
   */
  items: any;
  /**
   * Value for inventory item id.
   */
  inventoryItemId: any;
  /**
   * Value for subinventory.
   */
  subInventory: any;
  /**
   * Value for polineid.
   */
  poLineId: any;
  /**
   * Value for lottype.
   */
  lotType: any;
  /**
   * Value for lot generation.
   */
  lotGeneration: any;
  /**
   * Value for itemslist.
   */
  itemsList: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl: ViewController, private singleton: SingletonProvider, private globalvars: GlobalvariablesProvider, private dataprovider: DataProvider) {
    this.modalText = this.navParams.get("data");
    this.inventoryItemId = this.navParams.get("invitemid");
    this.subInventory = this.navParams.get("subinventory");
    this.poLineId = this.navParams.get("lineid");
    console.log(this.inventoryItemId);
    /**
     * Check the modaltext is locators.
     */
    if (this.modalText === 'Locators') {
      if (this.globalvars.getDemo() === "1" || this.globalvars.getDemo() === 1) {
        this.getDemoLocators();
      } else {
        this.getLocators();
      }
      /**
       * Check the modaltext is lotnumber.
       */
    } else if (this.modalText === 'Lot Number') {
      this.getLotNumbers();
      /**
       * Check the modaltext is minserialnumber.
       */
    } else if (this.modalText === 'minserialnumber') {
      this.getSerialNumbers();
    } else {
      this.getSerialNumbers();
    }
  }

  /**
   * Method invoked when page is loaded.
   */
  ionViewDidLoad() {
    console.log('ionViewDidLoad SelectmodalPage');
  }

  // dismiss the model and passing the selected value
  /**
   * Method to dismiss the model.
   */
  dismiss() {
    this.viewCtrl.dismiss(this.selectedItem);
  }

  /**
   * Method to get the selected item from model.
   * 
   * @param item Selected item.
   */
  select(item) {
    this.selectedItem = item;
    console.log(this.selectedItem);
  }

  /**
   * Method to close the model.
   */
  cancel() {
    this.viewCtrl.dismiss();
    console.log("hiii");
  }

  // getting the list of locators

  /**
   * Method to get the locators list.
   */
  getLocators() {
    try {
      /**
       * Rest service for locators.
       */
      let locatorsUrl = this.singleton.locators;

      // let body = {
      //   "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
      //   "P_SUBINVENTORY_CODE": this.subInventory,
      //   "P_PO_LINE_ID":this.poLineId
      // }
      /**
       * Request body for locators rest service.
       */
      let body = {
        "INV_LOCATORS":
        {
          "@xmlns": "http://xmlns.oracle.com/apps/ar/rest/INV_LOCATORS/get_locator_f/",
          "RESTHeader":
          {
            "xmlns": "http://xmlns.oracle.com/apps/ar/rest/INV_LOCATORS/get_cm_hdr_dtls_p/",
            "Responsibility": "SYSTEM_ADMINISTRATOR",
            "RespApplication": "SYSADMIN",
            "SecurityGroup": "STANDARD",
            "NLSLanguage": "AMERICAN",
            "Org_Id": "7914"
          },
          "InputParameters":
          {
            "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
            "P_SUBINVENTORY_CODE": this.subInventory,
            "P_PO_LINE_ID": this.poLineId
          }
        }
      }
      console.log(body);
      /**
       * Calling of locator rest service using dataprovider getcommondata method.
       */
      this.dataprovider.getCommonData(locatorsUrl, body).subscribe(data => {
        console.log(data);
        let dataString = data.OutputParameters.GET_LOCATOR_F;
        console.log(dataString);
        if (typeof dataString === 'object') {

        } else {
          let resultList = JSON.parse(dataString);
          console.log(resultList.data);
          this.items = resultList.data;
          this.initializeItems();
        }
      })

    } catch (e) {
      console.log("error");
    }
  }

  // getting list of lot numbers
  /**
   * Method to get the lotnumbers list.
   */
  getLotNumbers() {
    try {
      /**
       * Rest service for lotnumber list.
       */
      let lotnumbersUrl = this.singleton.lotNumbers;

      // let body = {
      //   "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
      //   "P_INVENTORY_ITEM_ID": this.inventoryItemId,
      //   "P_PO_LINE_ID": this.poLineId
      // }

      /**
       * Request body for lotnumber list rest service.
       */
      let body = {
        "INV_LOT_NUMBERS":
        {
          "@xmlns": "http://xmlns.oracle.com/apps/ar/rest/INV_LOT_NUMBERS/get_lot_number_f/",
          "RESTHeader":
          {
            "xmlns": "http://xmlns.oracle.com/apps/ar/rest/INV_LOT_NUMBERS/get_cm_hdr_dtls_p/",
            "Responsibility": "SYSTEM_ADMINISTRATOR",
            "RespApplication": "SYSADMIN",
            "SecurityGroup": "STANDARD",
            "NLSLanguage": "AMERICAN",
            "Org_Id": "7911"
          },
          "InputParameters":
          {
            "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
            "P_INVENTORY_ITEM_ID": this.inventoryItemId,
            "P_PO_LINE_ID": this.poLineId
          }
        }
      }

      /**
       * Calling of lotnumber rest service using dataprovider getcommondata method.
       */
      this.dataprovider.getCommonData(lotnumbersUrl, body).subscribe(data => {
        console.log(data);
        let dataString = data.OutputParameters.GET_LOT_NUMBER_F;
        console.log(dataString);
        if (typeof dataString === 'object') {

        } else {
          let resultList = JSON.parse(dataString);
          console.log(resultList.data);
          this.items = resultList.data;
          this.initializeItems();
          this.lotType = resultList.data[0].LOT_TYPE;
          this.lotGeneration = resultList.data[0].LOT_GENERATION;
        }
      })

    } catch (e) {
      console.log("error");
    }
  }

  // getting the list of serial numbers
  /**
   * Method to get the serial numbers list.
   */
  getSerialNumbers() {
    try {
      /**
       * Rest service for serial numbers list.
       */
      let serialNumbersUrl = this.singleton.serialNumbers;

      // let body = {
      //   "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
      //   "P_INVENTORY_ITEM_ID": this.inventoryItemId,
      //   "P_PO_LINE_ID": this.poLineId
      // }

      /**
       * Request body for serial numbers list rest service.
       */
      let body =
        {
          "INV_SERIAL_NUMBERS":
          {
            "@xmlns": "http://xmlns.oracle.com/apps/po/rest/INV_SERIAL_NUMBERS/get_serial_f/",
            "RESTHeader":
            {
              "xmlns": "http://xmlns.oracle.com/apps/po/rest/INV_SERIAL_NUMBERS/header",
              "Responsibility": "SYSTEM_ADMINISTRATOR",
              "RespApplication": "SYSADMIN",
              "SecurityGroup": "STANDARD",
              "NLSLanguage": "AMERICAN"
            },
            "InputParameters":
            {
              "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
              "P_INVENTORY_ITEM_ID": this.inventoryItemId,
              "P_PO_LINE_ID": this.poLineId
            }
          }
        }
        /**
         * Calling of rest service using dataprovider getcommondata method.
         */
      this.dataprovider.getCommonData(serialNumbersUrl, body).subscribe(data => {
        console.log(data);
        let dataString = data.OutputParameters.GET_SERIAL_F;
        console.log(dataString);
        if (typeof dataString === 'object') {

        } else {
          let resultList = JSON.parse(dataString);
          console.log(resultList.data);
          this.items = resultList.data;
          this.initializeItems();
        }
      })

    } catch (e) {
      console.log("error");
    }
  }

  /**
   * Method to initialize the items to items list for serching.
   */
  initializeItems() {
    this.itemsList = this.items;
  }

  //for searching the  lot,locators,serial
  /**
   * Method to get the list according to searched item.
   * 
   * @param ev event for searching.
   */
  getItems(ev: any) {
    // Reset items back to all of the items
    this.initializeItems();

    // set val to the value of the searchbar
    let val = ev.target.value;
    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {
      console.log(this.itemsList);
      console.log(val);
      this.itemsList = this.itemsList.filter((item) => {
        if (this.modalText === 'Locators') {
          return (item.LOCATOR_LIST.toLowerCase().indexOf(val.toLowerCase()) > -1);
        } else if (this.modalText === 'Lot Number') {
          return (item.LOT_NUMBER.toLowerCase().indexOf(val.toLowerCase()) > -1);
        } else if (this.modalText === 'minserialnumber') {
          return (item.SERIAL_NUMBER.toLowerCase().indexOf(val.toLowerCase()) > -1);
        }
      })
    }

  }

  // get locators in demo mode

  /**
   * Method to get the demo locators from local json file.
   */
  getDemoLocators() {
    this.dataprovider.getSubInventoryJsonData().subscribe(data => {
      console.log(data);
      this.items = data.LOCATORS;
      this.initializeItems();
    });
  }
}

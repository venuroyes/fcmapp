import { DataProvider } from './../../providers/data/data';
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { InAppBrowser } from '@ionic-native/in-app-browser';

/**
 * Generated class for the HelpPage page.
 *
 * HelpPage class to get the faq's from the local file and show on the component.
 * 
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-help',
  templateUrl: 'help.html',
})
export class HelpPage {
  /**
   * Value for faq's.
   */
    faq:any;
  constructor(public navCtrl: NavController, public navParams: NavParams,private iab: InAppBrowser, public data: DataProvider) {
    this.data.getFaqData().subscribe(result => {
      this.faq = result;
      console.log(this.faq);
    })
  }

  /**
   * Method invoked when page is loaded.
   */
  ionViewDidLoad() {
    console.log('ionViewDidLoad HelpPage');
  }

  /**
   * Method to open the url in the browser using inapp browser.
   */
  openBrowser(){
    console.log("Browser");
    this.iab.create('https://drift.me/algarytm');
  }

}

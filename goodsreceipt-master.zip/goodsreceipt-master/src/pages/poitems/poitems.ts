import { Sample } from './../../models/jsondata/jsonsample.interface';
import { DatabaseProvider } from './../../providers/database/database';
import { PolistPage } from './../polist/polist';
import { ReceiptsPage } from './../receipts/receipts';
import { DataProvider } from './../../providers/data/data';
import { SingletonProvider } from './../../providers/singleton/singleton';
import { GlobalvariablesProvider } from './../../providers/globalvariables/globalvariables';
import { PoitemdetailPage } from './../poitemdetail/poitemdetail';
import { Component, ViewChild, Input } from '@angular/core';
import { NavController, NavParams, LoadingController } from 'ionic-angular';
import { Keyboard } from '@ionic-native/keyboard';
import { AlertController } from 'ionic-angular';
import { File } from '@ionic-native/file';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';

/**
 * Generated class for the PoitemsPage page.
 *
 * PoitemsPage class to get the poitems from the rest service and send the data to generate receipt.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */


@Component({
  selector: 'page-poitems',
  templateUrl: 'poitems.html',
})


export class PoitemsPage {
  // @ViewChild('input') myInput ;

  /**
   * Value for the list from previous page.
   */
  poSubList: any;
  /**
   * Value dor poitems list.
   */
  poItemsList: any;
  /**
   * Value for poheaderid.
   */
  poHeaderId: any;
  /**
   * Value for porelease.
   */
  poRelease: any;
  /**
   * Value for items.
   */
  items: any;
  /**
   * Value for selecting all.
   */
  selectall: any;
  /**
   * Value for lineitem.
   */
  lineitem: any;
  /**
   * Value for selected.
   */
  selected: any;
  /**
   * Value for selectedall.
   */
  selectedAll: any;
  /**
   * Value for poreleaseid.
   */
  poReleaseId: any;
  /**
   * Value for listlines.
   */
  listLines = [];
  /**
   * Value for csvlines.
   */
  csvLines = [];
  /**
   * Value for jsonsample object.
   */
  jsonsample = {} as Sample;
  /**
   * Value for checked lines.
   */
  checkedLines = [];
  /**
   * Value for clicked.
   */
  clicked:any = true;
  /**
   * Value for loading controller.
   */
  loading = this.loadCtrl.create({
    content: 'Please wait...'
  });
  poNumber:any;

  data = [
    {DELIVERY_DATE: "23-11-2014", quantity: 2, total: 200, tip: 0,   type: "cash"},
    {DELIVERY_DATE: "30-11-2010", quantity: 1, total: 300, tip: 200, type: "visa"},
    {DELIVERY_DATE: "21-11-2015", quantity: 2, total: 90,  tip: 0,   type: "tab"},
    {DELIVERY_DATE: "22-1-2019", quantity: 2, total: 90,  tip: 0,   type: "tab"},
    {DELIVERY_DATE: "22-2-2020", quantity: 2, total: 90,  tip: 0,   type: "tab"},
    {DELIVERY_DATE: "20-1-2022", quantity: 2, total: 90,  tip: 0,   type: "tab"},
    {DELIVERY_DATE: "20-3-2012", quantity: 1, total: 200, tip: 100, type: "visa"},
    {DELIVERY_DATE: "02-01-2000", quantity: 2, total: 190, tip: 100, type: "tab"},
    ];
  constructor(public alertCtrl: AlertController,public loadCtrl: LoadingController, private transfer: FileTransfer, public file: File, public navCtrl: NavController, public navParams: NavParams, private globalvars: GlobalvariablesProvider, private singleton: SingletonProvider, private dataprovider: DataProvider, private keyboard: Keyboard, private databaseprovider: DatabaseProvider) {
    if (this.globalvars.getDemo() === "1" || this.globalvars.getDemo() === 1) {
      this.poSubList = this.navParams.get("data");
      this.poItemsList = this.poSubList.LINE_ITEM;
      this.initializeItems();
      console.log(this.poSubList);
    } else {
      this.poSubList = this.navParams.get("data");
      this.poHeaderId = this.poSubList.PO_HEADER_ID;
      this.poRelease = this.poSubList.RELEASES;
      this.poReleaseId = this.poSubList.RELEASE_ID;
      this.poNumber=this.poSubList.PO_NUMBER;
      console.log(this.selectall);
      console.log(this.poSubList);
      this.globalvars.setPoHeaderId(this.poHeaderId);
      // this.globalvars.setponumber(this.poNumber);
      // this.globalvars.setsubInventory("");
      this.getLineItems();
      // console.log(this.data);
      // this.sortingItems(this.data);
    //   let sortdatadesc=this.sortingItems(this.data);
    //   // this.sortBy(this.data, { prop: "date" });

    //   console.log(sortdatadesc);
    //  let sortdataascen= sortdatadesc.reverse();
    //   console.log(sortdataascen);

    }
  }

  /**
   * Method invoked when page is loaded.
   */
  ionViewDidLoad() {
    console.log('ionViewDidLoad PoitemsPage');
    // this.getSqliteLines();

  }

  sortingItems(items) {
    console.log("items before sorting");
    console.log(items)
    items.sort(function (a, b) {
      // convert date object into number to resolve issue in typescript
      return +new Date(a.DELIVERY_DATE) - +new Date(b.DELIVERY_DATE);
    });
    this.poItemsList = items;
    console.log("sorting of items after data");
    console.log(items);
    // return items

  }

   sortBy = (function () {
    var toString = Object.prototype.toString,
        // default parser function
        parse = function (x) { return x; },
        // gets the item to be sorted
        getItem = function (x) {
          var isObject = x != null && typeof x === "object";
          var isProp = isObject && this.prop in x;
          return this.parser(isProp ? x[this.prop] : x);
        };

    /**
     * Sorts an array of elements.
     *
     * @param {Array} array: the collection to sort
     * @param {Object} cfg: the configuration options
     * @property {String}   cfg.prop: property name (if it is an Array of objects)
     * @property {Boolean}  cfg.desc: determines whether the sort is descending
     * @property {Function} cfg.parser: function to parse the items to expected type
     * @return {Array}
     */
    return function sortby (array, cfg) {
      if (!(array instanceof Array && array.length)) return [];
      if (toString.call(cfg) !== "[object Object]") cfg = {};
      if (typeof cfg.parser !== "function") cfg.parser = parse;
      cfg.desc = !!cfg.desc ? -1 : 1;
      return array.sort(function (a, b) {
        a = getItem.call(cfg, a);
        b = getItem.call(cfg, b);
        return cfg.desc * (a < b ? -1 : +(a > b));
      });
    };

  }());


  /**
   * Method to go to next page with item.
   *
   * @param item object from the list.
   */
  goToItemDetails(item) {
    this.navCtrl.push(PoitemdetailPage, { data: item ,data1:this.poNumber});
  }

  /**
   * Method to get the value of check box.
   *
   * @param item value of the checkbox.
   */
  updateItem(item) {
    console.log(item.checked);
    console.log(item.ITEM);
    this.databaseprovider.updatereceipt(item.QUAN_RECV,item.LINE_LOCATION_ID);

    /**
     * If checkbox is checked values pushed to checkedLines array.
     */
    if (item.checked == true) {
      this.checkedLines.push(item);
    } else if (item.checked == false) {
      // this.selectall = false;
      let index = this.checkedLines.indexOf(item.checked);
      console.log(index + "this is index");
      if (index = -1) {
        this.checkedLines.splice(index, 1);
        console.log(this.checkedLines + "when cked false");
      }
    } else {
      this.checkedLines = [];
    }
    console.log(this.selectedAll+ "this is unselectesd");
  }

  // to select all the items

  // updateItem(){
  //   this.selectall = this.items.every(function(item){
  //     return item.selected == true;
  //   })

  // }

  /**
   * Method to set the selectall check box value.
   */
  setValue() {
      // this.items.forEach(element => {
      //   element.selected = this.selectall;
      // });
    console.log(this.selectall);
    if (this.selectall === true) {
      this.selectedAll = true;
      // console.log(this.checkedLines + "selected all");
    } else {
      this.selectedAll = false;
      this.checkedLines = [];
      // console.log(this.checkedLines + "selected all false");
    }
  }


  /**
   * Method to sett the input field in the item so that the item is clickable.
   *
   * @param event event to set input.
   */
  someInput(event,item){
    console.log(event);
    console.log(item);
    event.stopPropagation();
    // his.databaseprovider.updatereceipt(item.QUAN_RECV,item.LINE_LOCATION_ID);
    this.databaseprovider.updatereceipt(event,item.LINE_LOCATION_ID).then(res => {
      console.log(res);

    }).catch(e => {
      console.log("error message" + e.code);


    })
  }

  // to get the line items for particular headeId

  /**
   * Method to get the line items from the service.
   */
  getLineItems() {
   let loading = this.loadCtrl.create({
      content: 'Please wait...'
    });
    loading.present();
    try {
      // lineitems url
      /**
       * REst service for po line items.
       */
      let poLineItemUrl = this.singleton.poLineDetails;

      /**
       * Request body for poline items rest service.
       */
      let body = {
        "GDS_PO_LN_DTLS":
        {
          "@xmlns": "http://xmlns.oracle.com/apps/po/rest/GDS_PO_LN_DTLS/get_po_line_dtls_f/",
          "RESTHeader":
          {
            "xmlns": "http://xmlns.oracle.com/apps/po/rest/GDS_PO_LN_DTLS/header",
            "Responsibility": "SYSTEM_ADMINISTRATOR",
            "RespApplication": "SYSADMIN",
            "SecurityGroup": "STANDARD",
            "NLSLanguage": "AMERICAN"
          },
          "InputParameters":
          {
            "P_ORG_ID": this.globalvars.getOrgId(),
            "P_ORGANIZATION_ID": this.globalvars.getInvOrgId(),
            "P_PO_HEADER_ID": this.poHeaderId,
            "P_RELEASE_NUM": this.poRelease,
            "P_PO_RELEASE_ID": this.poReleaseId
          }
        }
      }

      // getting the data by calling the service from DataProvider

      /**
       * Calling of poline items rest service using dataprovider getgoodsdata method.
       */
      this.dataprovider.getGoodsData(poLineItemUrl, body).subscribe(data => {
        console.log(data);
        let dataString = data.OutputParameters.GET_PO_LINE_DTLS_F;
        console.log(dataString);
        if (typeof dataString === 'object') {

        } else {
          let resultList = JSON.parse(dataString);
          console.log(resultList.data);
          this.poItemsList = resultList.data;
          this.sortingItems(this.poItemsList);
          this.databaseprovider.insertIntoPolines(this.poItemsList).then(res => {
            console.log(res);
          }).catch(e => {
            console.log("error" + e);
          });

          this.initializeItems();
          console.log(this.poItemsList);
        }
      })
    loading.dismiss();
    } catch (e) {
      console.log("error");
      loading.dismiss();
    }

    // this.databaseprovider.getLineItemsOffline(this.poHeaderId).then(res => {
    //   console.log(res+"this is offline items");
    //   if (res.rows.length > 0) {
    //     console.log("this is offline");
    //     for (var i = 0; i < res.rows.length; i++) {
    //       // this.listdis.push({ponumber: res.rows.item(i).PO_NUMBER,releases: res.rows.item(i).ELEASES, poheaderid: res.rows.item(i).PO_HEADER_ID, potype: res.rows.item(i).PO_TYPE, vendorname: res.rows.item(i).VENDOR_NAME, vendorsite: res.rows.item(i).VENDOR_SITE, items: res.rows.item(i).ITEMS, contract: res.rows.item(i).CONTRACT, requestor: res.rows.item(i).REQUESTOR, headerprice: res.rows.item(i).PO_HDR_PRICE, currency: res.rows.item(i).CURRENCY_CODE, creationdate: res.rows.item(i).CREATION_DATE,lastdate: res.rows.item(i).LAST_UPDATE_DATE });
    //       this.poItemsList.push(res.rows.item(i));
    //     }
    //     console.log(JSON.stringify(this.poItemsList)+"this is listids");
    //     this.initializeItems();
    //   }

    // })


  }

  // sortBy () {
  //   var toString = Object.prototype.toString,
  //       // default parser function
  //       parse = function (x) { return x; },
  //       // gets the item to be sorted
  //       getItem = function (x) {
  //         var isObject = x != null && typeof x === "object";
  //         var isProp = isObject && this.prop in x;
  //         return this.parser(isProp ? x[this.prop] : x);
  //       };


  //     return function sortby (array, cfg) {
  //       if (!(array instanceof Array && array.length)) return [];
  //       if (toString.call(cfg) !== "[object Object]") cfg = {};
  //       if (typeof cfg.parser !== "function") cfg.parser = parse;
  //       cfg.desc = !!cfg.desc ? -1 : 1;
  //       return array.sort(function (a, b) {
  //         a = getItem.call(cfg, a);
  //         b = getItem.call(cfg, b);
  //         return cfg.desc * (a < b ? -1 : +(a > b));
  //       });
  //     };

  //   }());



  /**
   * Method to initialize poitemslist to items.
   */
  initializeItems() {
    this.items = this.poItemsList;
  }

  //for searching the purchase order line item according to the po number
  /**
   * Method to get the items searched.
   *
   * @param ev event for searching.
   */
  getItems(ev: any) {
    // Reset items back to all of the items
    this.initializeItems();

    // set val to the value of the searchbar
    let val = ev.target.value;
    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {
      console.log(this.poItemsList);
      console.log(val);
      this.items = this.items.filter((item) => {
        return (item.ITEM.toLowerCase().indexOf(val.toLowerCase()) > -1) || (item.DESCRIPTION.toLowerCase().indexOf(val.toLowerCase()) > -1);

      })
    }

  }


  /**
   * Method to perform the receipt.
   */
  goToReceiptPage() {
    // this.navCtrl.push(ReceiptsPage);
    if (this.globalvars.getDemo() === "1" || this.globalvars.getDemo() === 1) {
      this.loading.present();
      setTimeout(() => {
        this.loading.dismiss();
        this.showAlert();
      }, 5000);
    } else {
      this.loading.present();

      if (this.checkedLines.length > 0) {
        this.retrieveData(this.checkedLines);

      } else {
         this.loading.dismiss() /* loading error   venu  */
        let alert = this.alertCtrl.create({
          subTitle: 'Please select the line item to perform receipt',
          buttons: [{
            text: 'OK'
          }]
        });
        alert.present();
      }
    }

    this.globalvars.setsubInventory("");
    this.globalvars.setponumber("");
    this.globalvars.setLocators("");
    this.globalvars.setlotnumber('');
    this.globalvars.setMinserialnumber('');
    this.globalvars.setMaxserialnumber('');

  }
  // onFocus(){
  //   console.log("focuss3d");
  // }

  /**
   * Method to show alert for demo mode.
   */
  showAlert() {
    let alert = this.alertCtrl.create({
      subTitle: 'Receipt is generated with Receipt Number: 9',
      enableBackdropDismiss:false,
      buttons: [{
        text: 'OK',
        handler: () => {
          this.navCtrl.setRoot(PolistPage);
        }
      }]
    });
    alert.present();
  }

  // getting data from sqlite database

  /**
   * Method to get data from PURCHASEORDER_ITEMS table from Sqlite database.
   */
  getSqliteLines() {
    this.databaseprovider.getList("PURCHASEORDER_ITEMS").then(res => {
      console.log(res + "this is res");
      if (res.rows.length > 0) {
        for (var i = 0; i < res.rows.length; i++) {
          // this.listdis.push({ponumber: res.rows.item(i).PO_NUMBER,releases: res.rows.item(i).ELEASES, poheaderid: res.rows.item(i).PO_HEADER_ID, potype: res.rows.item(i).PO_TYPE, vendorname: res.rows.item(i).VENDOR_NAME, vendorsite: res.rows.item(i).VENDOR_SITE, items: res.rows.item(i).ITEMS, contract: res.rows.item(i).CONTRACT, requestor: res.rows.item(i).REQUESTOR, headerprice: res.rows.item(i).PO_HDR_PRICE, currency: res.rows.item(i).CURRENCY_CODE, creationdate: res.rows.item(i).CREATION_DATE,lastdate: res.rows.item(i).LAST_UPDATE_DATE });
          this.listLines.push(res.rows.item(i));
        }
      }
    });
  }

  /**
   * Method to perform the receipt by convertint the data to CSV format.
   *
   * @param checkeditems checked items
   */
  retrieveData(checkeditems) {
    console.log(checkeditems);
    /**
     * Get the data of the checked items from the Sqlite database.
     */
    this.databaseprovider.getReceiptElements(checkeditems).then((res) => {

      console.log(res + "this is res of the joimns");
      // this.csvLines = res;
      // let receptLines=[];
      console.log(res.rows.length + "this is the length of outpiut");
      if (res.rows.length > 0) {
        for (var i = 0; i < res.rows.length; i++) {
          // this.csvLines.push({PO_LINE_LOCATION_ID:res.rows.item(i).LINE_LOCATION_ID,PO_HEADER_ID:res.rows.item(i).PO_HEADER_ID,PO_RELESE_NUM:res.rows.item(i).RELESENUM,QUANTITY_RECEIVED:res.rows.item(i).QUNATITY_RECV,DESTINATION_TYPE:res.rows.item(i).DESTINATION,INV_ORG_ID:res.rows.item(i).ORG_ID,SUB_INVENTORY:res.rows.item(i).SUBINVENTORY,LOCATOR:res.rows.item(i).LOCATOR,LOT:res.rows.item(i).LOT,MAX_SERIAL:res.rows.item(i).MAX_SERIAL,MIN_SERIAL:res.rows.item(i).MIN_SERIAL,DELIVERY_DATE:res.rows.item(i).DELIVERY_DATE,USER_ID:res.rows.item(i).USERID})
          this.csvLines.push(res.rows.item(i));
      }
      }
      console.log(this.csvLines + "this is some values in table");
      if (this.csvLines.length > 0) {
        this.createCSV(this.csvLines);
        console.log(this.csvLines + "array of output");
      } else {
        console.log("Not created");
        this.loading.dismiss();
        let alert = this.alertCtrl.create({
          subTitle: 'Please go to item details to store the data and perform receipt',
          buttons: [{
            text: 'OK',
            // handler: () => {
            //   this.navCtrl.setRoot(PolistPage);
            // }
          }]
        });
        alert.present();
      }
    }, (err) => {
      console.log(err.message + "joins error");
    });
  }

  /**
   * Method to convert the list of data into CSv format using json to csv package.
   *
   * @param list rows of the checked items from database.
   */
  createCSV(list) {
    var json2csv = require('json2csv');
    // var fs = require('fs');
    var fields = ['LINE_LOCATION_ID', 'PO_HEADER_ID', 'RELESENUM', 'QUNATITY_RECV', 'DESTINATION', 'ORG_ID', 'SUBINVENTORY', 'LOCATOR', 'LOT', 'MAX_SERIAL', 'MIN_SERIAL', 'RECEIPT_DATE', 'USERID'];
    var myLines = list;
    var opts = {
      data: myLines,
      fields: fields,
      fieldNames: fields,
      quotes: '',
      newLine: ";"
    };
    var csv = json2csv(opts);
    console.log(csv + "this is csv" + typeof csv);
    /**
     * REst api for creating the receipt.
     */
    let interfaceUrl = this.singleton.interfacecsv;
    /**
     * Request body for interface rest service.
     */
    let body = {
      "parse_csv":
      {
        "@xmlns": "http://vis1225.dpebs-server.com:8000/webservices/rest/parse_csv/get_parse_json_p",
        "RESTHeader":
        {
          "xmlns": "http://vis1225.dpebs-server.com:8000/webservices/rest/parse_csv/header",
          "Responsibility": "SYSTEM_ADMINISTRATOR",
          "RespApplication": "SYSADMIN",
          "SecurityGroup": "STANDARD",
          "NLSLanguage": "AMERICAN",
          "Org_Id": "7914"
        },
        "InputParameters":
        {
          "P_CSV_DATA": csv
        }
      }
    }



    /**
     * Calling of the interface rest service using dataprovider getgoodsdata method.
     */
    this.dataprovider.getGoodsData(interfaceUrl, body).subscribe(receiptdata => {

      console.log(receiptdata);
      this.loading.dismiss();
      let dataString = receiptdata.OutputParameters.V_RECEIPT_NUMBER_OUT;
      let message = receiptdata.OutputParameters.V_RECEIPT_MESSAGE_OUT;
      console.log(dataString);
      /**
       * If there is no data received from the service.
       */
      if (typeof dataString === 'object') {
        let alert = this.alertCtrl.create({
          subTitle: 'Receipt is not generated. Please check the data',
          buttons: [{
            text: 'OK',
            // handler: () => {
            //   this.navCtrl.setRoot(PolistPage);
            // }
          }]
        });
        alert.present();
      } else {
        let resultList = dataString;
        let resultmessage = message;
        console.log(resultList + "this is receipt number");
        /**
         * If the result message is success.
         */
        if (resultmessage == "SUCCESS") {
          this.receiptAlert(resultList);
          csv="";
          /**
           * Delete the selected rows data after the receipt is performed.
           */
          this.databaseprovider.deleteList("PURCHASEORDER_ITEMS", this.checkedLines).then((res) => {
                console.log("this row is line deleted" + res);
                if(res.rows.length > 0){
                  this.databaseprovider.deleteList("PO_ITEM_DETAILS",this.checkedLines).then((result) => {
                    console.log("this rows deleted from poitem details"+ result);
                    if(result.rows.length > 0){
                      this.databaseprovider.deleteList("RECEIPT_ITEM_DETAILS",this.checkedLines).then((response) => {
                        console.log("this row deleted from receipt details"+ response);
                      }),(err => {
                        console.log("error for deleting receipt details" + err);
                      })
                    }
                  }),(err => {
                    console.log("error for deleting poitem details" + err);
                  })
                }
              }), (err => {
                console.log("error for line deleting" + err);
              })
        }else{
          this.receiptError(resultList);
        }
      }
    });

    console.log(this.file.dataDirectory + "data directory");
    this.file.writeFile(this.file.externalDataDirectory, 'sample.csv', csv).then(res => {
      if (res) {
        console.log(res);
        // this.uploadFile();
      }
    });
  }


  /**
   * Method to upload a file.
   */
  uploadFile() {
    const fileTransfer: FileTransferObject = this.transfer.create();
    //   let options: FileUploadOptions = {
    //     fileKey: 'sample',
    //     fileName: 'sample.csv',
    //  }
    let fileurl = encodeURI('/opt/ebs/oracle/VIS/12.1.0/appsutil/outbound/VIS_ebsol');
    console.log(this.file.externalDataDirectory + 'sample.csv');
    fileTransfer.upload(this.file.externalDataDirectory + 'sample.csv', fileurl)
      .then((data) => {
        // success
        console.log(data);
      }, (err) => {
        // error
        console.log(err.code + "this is error");
      })
  }

  /**
   * Method to show alert after the success of the receipt generation.
   *
   * @param receiptNum Receipt number received from rest service after success.
   */
  receiptAlert(receiptNum) {
    let alert = this.alertCtrl.create({
      // subTitle: 'Receipt is generated with Receipt Number:' + receiptNum,
      subTitle: 'Received successfully with the receipt number :' + receiptNum,
      buttons: [{
        text: 'OK',
        handler: () => {
          this.navCtrl.setRoot(PolistPage);
        }
      }]
    });
    alert.present();

  }

  /**
   * Method to show alert with the error message.
   *
   * @param receiptError Error message from the service.
   */
  receiptError(receiptError){
    let alert = this.alertCtrl.create({
      subTitle: 'Error Message:' + receiptError,
      buttons: [{
        text: 'OK',
        handler: () => {
          this.navCtrl.setRoot(PolistPage);
        }
      }]
    });
    alert.present();
  }


}

import { GlobalvariablesProvider } from './../../providers/globalvariables/globalvariables';
import { LoginPage } from './../login/login';
import { EmailValidator } from './../../validators/email';
import { FiredbProvider } from './../../providers/firedb/firedb';
import { Component } from '@angular/core';
import { NavController, NavParams, AlertController, MenuController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FormBuilder, FormGroup, Validators, AbstractControl, FormControl } from '@angular/forms';
import { SMS } from '@ionic-native/sms';
import { DatePipe } from '@angular/common';
import { Geolocation, Geoposition } from '@ionic-native/geolocation';
import { NativeGeocoder, NativeGeocoderReverseResult } from '@ionic-native/native-geocoder';
import { Platform } from 'ionic-angular';
import { LocationAccuracy } from '@ionic-native/location-accuracy';
/**
 * Generated class for the FormPage page.
 *
 * FormPage class to store or send the form details to firebase database.
 * 
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-form',
  templateUrl: 'form.html',
})
export class FormPage {
  /**
   * Value for users.
   */
  users: AngularFireList<any[]>;
  /**
   * Value for user form submit.
   */
  user: FormGroup;
  /**
   * Value for the country.
   */
  country: any;
  /**
   * Value for locality.
   */
  locality: any;
  /**
   * Value for sublocality.
   */
  sublocality: any;
  /**
   * Value for date application installed.
   */
  enteredDate: any;
  /**
   * Value for the device where app is installed.
   */
  device: any;
  constructor(public navCtrl: NavController, 
              private locationAccuracy: LocationAccuracy, 
              public plt: Platform, 
              public storage: Storage, 
              private datePipe: DatePipe, 
              public menu: MenuController, 
              public angFire: AngularFireDatabase, 
              private formBuilder: FormBuilder, 
              public navParams: NavParams, 
              public firebaseProvider: FiredbProvider, 
              private globalvars: GlobalvariablesProvider, 
              public alertCtrl: AlertController, 
              private sms: SMS, 
              public geolocation: Geolocation, 
              public geocoder: NativeGeocoder) {
    // this.users = this.firebaseProvider.getUsers();
    /**
     * Check the platform.
     */
    if (this.plt.is('ios')) {
      this.device = "IOS";
    } else if (this.plt.is('android')) {
      this.device = "ANDROID";
    } else {
      this.device = "nothing";
    }
    /**
     * Form group validation for the form.
     */
    this.user = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.minLength(4)]),
      email: new FormControl('', [Validators.required, Validators.pattern(/^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i), EmailValidator.checkEmail]),
      agree: new FormControl(false, Validators.pattern('true'))
    });
    this.menu.swipeEnable(false);
  }

  /**
   * Method invoked when page is loaded.
   */
  ionViewDidLoad() {
    console.log('ionViewDidLoad FormPage');
  }


  /**
   * Method to submit the form details to firebase.
   * 
   * @param registerform Object of the form details.
   */
  onSubmit(registerform) {
    let accuracyoptions = {
      enableHighAccuracy: true
    };
    // this.locationAccuracy.canRequest().then((res: boolean) => {
      // if (res) {
        // this.locationAccuracy.request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(() => {
        /**
         * To check the location is enabled or not using location accuracy and get the current location.
         */  
        this.geolocation.getCurrentPosition(accuracyoptions).then((position: Geoposition) => {
            this.getcountry(position, registerform);
          }).catch((err) => {
            console.log("Error" + err);
          })
        // }, (error) => {
          // console.log("this is error while no gps"+error);
        // })
      // }
    // })
  }


  /**
   * Method to add the details of form and the current position of user to firebase database.
   * 
   * @param pos Current position of the user.
   * @param registerform From details entered by user.
   */

  getcountry(pos, registerform) {
    /**
     * Converting the latitute and longitude into the country and locality name and other details.
     */
    this.geocoder.reverseGeocode(pos.coords.latitude, pos.coords.longitude).then((res: NativeGeocoderReverseResult[]) => {
      this.country = res[0].countryName;
      this.locality = res[0].locality;
      this.sublocality = res[0].subLocality;
      this.enteredDate = this.datePipe.transform(new Date(), 'dd-MMM-yyyy');

      /**
       * Adding the details to firebase database.
       */
      this.firebaseProvider.addUser(registerform.value.name, registerform.value.email, "Goods Receipt", this.country, this.locality, this.sublocality, this.enteredDate, this.device);
      let msg = "Thank You for submitting the details";
      let alert = this.alertCtrl.create({
        title: msg,
        enableBackdropDismiss: false,
        buttons: [
          {
            text: "ok",
            handler: () => {
              this.navCtrl.setRoot(LoginPage);
              this.storage.set('introShown', true);
            }

          }
        ]

      });
      alert.present();
    })

  }

}
